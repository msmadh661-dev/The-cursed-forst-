import { useCallback, useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import {
  BookOpen,
  Compass,
  Eye,
  Play,
  RotateCcw,
  ShieldAlert,
  Sparkles,
  Trophy,
} from 'lucide-react';
import {
  animateMonster,
  animateSurvivor,
  buildMonsterCharacter,
  buildSurvivorCharacter,
  SurvivorRig,
} from './game/characterModels';
import { buildForestWorld, TreeObstacle } from './game/forestWorld';
import { soundEngine } from './game/soundEngine';
import {
  ActiveFlare,
  CameraPerspective,
  CollectibleItem,
  CompassMarker,
  DifficultyLevel,
  GamePhase,
  MonsterEntity,
  PlayerStats,
  RadioBeacon,
} from './game/types';
import { TacticalHUD } from './components/TacticalHUD';
import { CharacterInspectorModal } from './components/CharacterInspectorModal';

const INITIAL_STATS: PlayerStats = {
  health: 100,
  maxHealth: 100,
  stamina: 100,
  maxStamina: 100,
  battery: 100,
  maxBattery: 100,
  flashlightOn: true,
  highBeamActive: false,
  isCrouching: false,
  isSprinting: false,
  flaresCount: 3,
  medkitsCount: 2,
  beaconsActivated: 0,
  totalBeacons: 4,
  extractionReady: false,
  extractionProgress: 0,
  heartbeatBpm: 72,
  nearestMonsterDist: 99,
  dangerLevel: 0,
  noiseLevel: 0.1,
  headingDeg: 0,
  cameraMode: 'third-person',
  activePromptAr: null,
  statusMessageAr: 'فعّل أبراج الإشارة الأربعة في الغابة لطلب مروحية الإنقاذ',
  survivedSeconds: 0,
  monstersRepelled: 0,
  collectedNotes: [],
};

export function App() {
  const canvasContainerRef = useRef<HTMLDivElement | null>(null);

  const [gamePhase, setGamePhase] = useState<GamePhase>('title');
  const [difficulty, setDifficulty] = useState<DifficultyLevel>('normal');
  const [stats, setStats] = useState<PlayerStats>(INITIAL_STATS);
  const [compassMarkers, setCompassMarkers] = useState<CompassMarker[]>([]);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [showInspector, setShowInspector] = useState<boolean>(false);
  const [latestNotePopup, setLatestNotePopup] = useState<string | null>(null);

  // Mutable refs for real-time 60fps loop access
  const phaseRef = useRef<GamePhase>('title');
  const difficultyRef = useRef<DifficultyLevel>('normal');
  const statsRef = useRef<PlayerStats>({ ...INITIAL_STATS });

  // Player spatial state
  const playerPosRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 0, 0));
  const yawRef = useRef<number>(0); // 0 = looking North (-Z)
  const pitchRef = useRef<number>(0);
  const keysRef = useRef<Record<string, boolean>>({});
  const interactHoldRef = useRef<boolean>(false);
  const highBeamHoldRef = useRef<boolean>(false);
  const isMouseDraggingRef = useRef<boolean>(false);
  const lastMousePosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // World entities refs
  const sceneRef = useRef<THREE.Scene | null>(null);
  const survivorRigRef = useRef<SurvivorRig | null>(null);
  const monstersRef = useRef<MonsterEntity[]>([]);
  const beaconsRef = useRef<RadioBeacon[]>([]);
  const collectiblesRef = useRef<CollectibleItem[]>([]);
  const activeFlaresRef = useRef<ActiveFlare[]>([]);
  const obstaclesRef = useRef<TreeObstacle[]>([]);
  const extractionZoneRef = useRef<{
    position: THREE.Vector3;
    radius: number;
    floodLight: THREE.PointLight;
    beaconColumn: THREE.Mesh;
  } | null>(null);

  useEffect(() => {
    phaseRef.current = gamePhase;
  }, [gamePhase]);

  useEffect(() => {
    difficultyRef.current = difficulty;
  }, [difficulty]);

  const setStatusBanner = useCallback((msg: string) => {
    statsRef.current.statusMessageAr = msg;
  }, []);

  // Spawn or reset monsters & world state when starting a new game
  const resetOrStartGame = useCallback(
    (chosenDifficulty: DifficultyLevel = difficultyRef.current) => {
      const scene = sceneRef.current;
      if (!scene) return;

      difficultyRef.current = chosenDifficulty;
      setDifficulty(chosenDifficulty);

      // Reset player transform
      playerPosRef.current.set(0, 0, 0);
      yawRef.current = 0;
      pitchRef.current = -0.05;

      // Reset stats
      statsRef.current = {
        ...INITIAL_STATS,
        flaresCount: chosenDifficulty === 'normal' ? 3 : 2,
        medkitsCount: chosenDifficulty === 'normal' ? 2 : 1,
        collectedNotes: [],
      };
      setStats({ ...statsRef.current });
      setLatestNotePopup(null);

      // Reset beacons
      beaconsRef.current.forEach((b) => {
        b.activated = false;
        b.activationProgress = 0;
        b.beaconLight.color.setHex(0xff3b30);
        b.statusLampMat.color.setHex(0xff3b30);
        b.statusLampMat.emissive.setHex(0xd92b2b);
      });

      // Reset collectibles
      collectiblesRef.current.forEach((c) => {
        c.collected = false;
        c.mesh.visible = true;
      });

      // Remove old active flares
      activeFlaresRef.current.forEach((f) => {
        scene.remove(f.mesh);
        scene.remove(f.light);
      });
      activeFlaresRef.current = [];

      // Reset extraction light
      if (extractionZoneRef.current) {
        extractionZoneRef.current.floodLight.intensity = 0;
        (extractionZoneRef.current.beaconColumn.material as THREE.MeshBasicMaterial).opacity = 0;
      }

      // Remove old monsters and spawn fresh realistic monsters
      monstersRef.current.forEach((m) => scene.remove(m.meshGroup));
      monstersRef.current = [];

      const monsterSpawns: Array<{ id: string; type: 'wendigo' | 'stalker' | 'creeper'; x: number; z: number }> = [
        { id: 'm-wendigo-1', type: 'wendigo', x: 0, z: -55 },
        { id: 'm-stalker-1', type: 'stalker', x: -38, z: 22 },
        { id: 'm-stalker-2', type: 'stalker', x: 40, z: 18 },
        { id: 'm-creeper-1', type: 'creeper', x: -36, z: -38 },
        { id: 'm-creeper-2', type: 'creeper', x: 38, z: -40 },
      ];

      if (chosenDifficulty === 'hardcore') {
        monsterSpawns.push({ id: 'm-wendigo-2', type: 'wendigo', x: -22, z: -68 });
      }

      monsterSpawns.forEach((sp) => {
        const m = buildMonsterCharacter(sp.id, sp.type, new THREE.Vector3(sp.x, 0, sp.z));
        scene.add(m.meshGroup);
        monstersRef.current.push(m);
      });

      soundEngine.startAmbientWind();
      setGamePhase('playing');
      phaseRef.current = 'playing';
    },
    []
  );

  // Action handlers
  const handleToggleFlashlight = useCallback(() => {
    if (statsRef.current.battery <= 0) {
      statsRef.current.flashlightOn = false;
      return;
    }
    statsRef.current.flashlightOn = !statsRef.current.flashlightOn;
    soundEngine.playFlashlightClick();
  }, []);

  const handleToggleCamera = useCallback(() => {
    const next: CameraPerspective =
      statsRef.current.cameraMode === 'third-person' ? 'first-person' : 'third-person';
    statsRef.current.cameraMode = next;
    setStatusBanner(
      next === 'third-person'
        ? 'تم التبديل إلى منظور الشخص الثالث (رؤية شخصية الناجي كاملة)'
        : 'تم التبديل إلى منظور الشخص الأول'
    );
  }, [setStatusBanner]);

  const handleToggleCrouch = useCallback(() => {
    statsRef.current.isCrouching = !statsRef.current.isCrouching;
    if (statsRef.current.isCrouching) {
      statsRef.current.isSprinting = false;
    }
  }, []);

  const handleUseMedkit = useCallback(() => {
    const st = statsRef.current;
    if (st.medkitsCount <= 0 || st.health >= st.maxHealth) return;
    st.medkitsCount -= 1;
    st.health = Math.min(st.maxHealth, st.health + 55);
    soundEngine.playPickupChime();
    setStatusBanner('تم استخدام حقيبة الإسعافات الأولية واستعادة الصحة الحيوية');
  }, [setStatusBanner]);

  const handleThrowFlare = useCallback(() => {
    const st = statsRef.current;
    const scene = sceneRef.current;
    if (!scene || st.flaresCount <= 0) return;

    st.flaresCount -= 1;
    soundEngine.playFlareIgnite();

    // Place flare slightly in front of player
    const forward = new THREE.Vector3(-Math.sin(yawRef.current), 0, -Math.cos(yawRef.current));
    const flarePos = playerPosRef.current.clone().addScaledVector(forward, 2.2);
    flarePos.y = 0.15;

    const flareGroup = new THREE.Group();
    flareGroup.position.copy(flarePos);

    const stick = new THREE.Mesh(
      new THREE.CylinderGeometry(0.05, 0.05, 0.38, 10),
      new THREE.MeshStandardMaterial({
        color: 0xff2a1f,
        emissive: 0xff3b2f,
        emissiveIntensity: 4.5,
      })
    );
    stick.rotation.z = Math.PI / 2;
    flareGroup.add(stick);

    const aura = new THREE.Mesh(
      new THREE.SphereGeometry(0.28, 12, 12),
      new THREE.MeshBasicMaterial({
        color: 0xff6b4a,
        transparent: true,
        opacity: 0.65,
      })
    );
    flareGroup.add(aura);

    const flareLight = new THREE.PointLight(0xff3824, 6.5, 22, 1.3);
    flareLight.position.copy(flarePos).setY(0.8);

    scene.add(flareGroup);
    scene.add(flareLight);

    activeFlaresRef.current.push({
      id: `flare-${Date.now()}`,
      position: flarePos,
      mesh: flareGroup,
      light: flareLight,
      remainingTime: 15,
    });

    setStatusBanner('تم إشعال مشعل ماغنيسيوم حراري! الوحوش القريبة تتراجع من وهج النار');
  }, [setStatusBanner]);

  // Main Three.js Scene Setup & 60fps Game Loop
  useEffect(() => {
    const container = canvasContainerRef.current;
    if (!container) return;

    const width = window.innerWidth;
    const height = window.innerHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x070b0a);
    scene.fog = new THREE.FogExp2(0x09110e, 0.032);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(62, width / height, 0.1, 160);

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Nocturnal Moonlight + Atmospheric Forest Hemisphere Light
    const hemiLight = new THREE.HemisphereLight(0x243b35, 0x080d0a, 0.65);
    scene.add(hemiLight);

    const moonLight = new THREE.DirectionalLight(0x7fa3b8, 0.85);
    moonLight.position.set(45, 75, 35);
    moonLight.castShadow = true;
    moonLight.shadow.mapSize.width = 2048;
    moonLight.shadow.mapSize.height = 2048;
    moonLight.shadow.camera.near = 10;
    moonLight.shadow.camera.far = 160;
    const d = 65;
    moonLight.shadow.camera.left = -d;
    moonLight.shadow.camera.right = d;
    moonLight.shadow.camera.top = d;
    moonLight.shadow.camera.bottom = -d;
    scene.add(moonLight);

    // Subtle personal ambient light around survivor so their realistic 3D character is always readable
    const survivorRimLight = new THREE.PointLight(0x52796f, 0.95, 5.5);
    scene.add(survivorRimLight);

    // Build Forest World
    const world = buildForestWorld(scene);
    obstaclesRef.current = world.obstacles;
    beaconsRef.current = world.beacons;
    collectiblesRef.current = world.collectibles;
    extractionZoneRef.current = world.extractionZone;

    // Build Realistic 3D Survivor ("آدم المنصور")
    const survivorRig = buildSurvivorCharacter();
    scene.add(survivorRig.root);
    survivorRigRef.current = survivorRig;

    // Spawn initial monsters so even the Title Screen has live 3D monsters prowling in the background
    const initialSpawns: Array<{ id: string; type: 'wendigo' | 'stalker' | 'creeper'; x: number; z: number }> = [
      { id: 'm-wendigo-title', type: 'wendigo', x: -3.2, z: -7.5 },
      { id: 'm-stalker-title', type: 'stalker', x: 4.2, z: -9.5 },
      { id: 'm-creeper-title', type: 'creeper', x: -35, z: 25 },
    ];
    initialSpawns.forEach((sp) => {
      const m = buildMonsterCharacter(sp.id, sp.type, new THREE.Vector3(sp.x, 0, sp.z));
      scene.add(m.meshGroup);
      monstersRef.current.push(m);
    });

    // Keyboard Listeners
    const onKeyDown = (e: KeyboardEvent) => {
      const code = e.code;
      keysRef.current[code] = true;

      if (phaseRef.current !== 'playing') return;

      if (code === 'KeyF') {
        handleToggleFlashlight();
      } else if (code === 'KeyV') {
        handleToggleCamera();
      } else if (code === 'KeyC') {
        handleToggleCrouch();
      } else if (code === 'KeyG') {
        handleThrowFlare();
      } else if (code === 'KeyH') {
        handleUseMedkit();
      } else if (code === 'KeyI') {
        setShowInspector((prev) => !prev);
      } else if (code === 'Escape' || code === 'KeyP') {
        setGamePhase((prev) => (prev === 'playing' ? 'paused' : prev === 'paused' ? 'playing' : prev));
      } else if (code === 'Space') {
        highBeamHoldRef.current = true;
      } else if (code === 'KeyE') {
        interactHoldRef.current = true;
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const code = e.code;
      keysRef.current[code] = false;
      if (code === 'Space') {
        highBeamHoldRef.current = false;
      } else if (code === 'KeyE') {
        interactHoldRef.current = false;
      }
    };

    // Mouse Look (supports both PointerLock AND click-drag so it works in all browsers/iframes)
    const onMouseMove = (e: MouseEvent) => {
      if (phaseRef.current !== 'playing') return;
      const sensitivity = 0.0026;
      if (document.pointerLockElement === renderer.domElement) {
        yawRef.current -= e.movementX * sensitivity;
        pitchRef.current = THREE.MathUtils.clamp(
          pitchRef.current - e.movementY * sensitivity,
          -0.65,
          0.65
        );
      } else if (isMouseDraggingRef.current) {
        const dx = e.clientX - lastMousePosRef.current.x;
        const dy = e.clientY - lastMousePosRef.current.y;
        lastMousePosRef.current = { x: e.clientX, y: e.clientY };
        yawRef.current -= dx * 0.0045;
        pitchRef.current = THREE.MathUtils.clamp(pitchRef.current - dy * 0.0035, -0.65, 0.65);
      }
    };

    const onMouseDown = (e: MouseEvent) => {
      if (phaseRef.current !== 'playing') return;
      if (e.button === 2) {
        highBeamHoldRef.current = true;
      } else if (e.button === 0) {
        isMouseDraggingRef.current = true;
        lastMousePosRef.current = { x: e.clientX, y: e.clientY };
        // Request pointer lock if clicking on the 3D canvas directly
        if (e.target === renderer.domElement && !document.pointerLockElement) {
          try {
            renderer.domElement.requestPointerLock?.();
          } catch {
            // fallback to drag
          }
        }
      }
    };

    const onMouseUp = (e: MouseEvent) => {
      if (e.button === 2) {
        highBeamHoldRef.current = false;
      } else if (e.button === 0) {
        isMouseDraggingRef.current = false;
      }
    };

    const onContextMenu = (e: MouseEvent) => e.preventDefault();

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('contextmenu', onContextMenu);

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // 60FPS Simulation & Render Loop
    let animationFrameId = 0;
    let hudSyncAccumulator = 0;
    const clock = new THREE.Clock();

    const resolveObstacleCollisions = (pos: THREE.Vector3, entityRadius: number) => {
      const obsList = obstaclesRef.current;
      for (let i = 0; i < obsList.length; i++) {
        const o = obsList[i];
        const dx = pos.x - o.x;
        const dz = pos.z - o.z;
        const minDist = entityRadius + o.radius;
        const distSq = dx * dx + dz * dz;
        if (distSq < minDist * minDist && distSq > 0.0001) {
          const dist = Math.sqrt(distSq);
          const push = minDist - dist;
          pos.x += (dx / dist) * push;
          pos.z += (dz / dist) * push;
        }
      }
      // Keep inside forest bounds
      pos.x = THREE.MathUtils.clamp(pos.x, -115, 115);
      pos.z = THREE.MathUtils.clamp(pos.z, -115, 115);
    };

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const dt = Math.min(clock.getDelta(), 0.1);
      const elapsed = clock.getElapsedTime();

      // Animate floating nocturnal spores
      world.particles.rotation.y = elapsed * 0.015;

      // ====================================================================
      // TITLE SCREEN CINEMATIC DIORAMA MODE
      // ====================================================================
      if (phaseRef.current === 'title') {
        survivorRig.root.visible = true;
        survivorRig.root.position.set(0, 0, 0);
        survivorRig.root.rotation.y = Math.PI * 0.15;
        animateSurvivor(survivorRig, elapsed, 0, false, false, 0.05, false);

        survivorRimLight.position.set(0.8, 1.8, 1.8);

        // Animate monsters in background of title screen
        monstersRef.current.forEach((m, idx) => {
          animateMonster(m, dt, true);
          m.meshGroup.position.x = (idx === 0 ? -2.6 : 3.2) + Math.sin(elapsed * 0.4 + idx) * 1.2;
          m.meshGroup.position.z = -5.5 - idx * 1.5;
          m.meshGroup.rotation.y = Math.PI;
        });

        // Slow dramatic camera orbit around the survivor and stalking monsters
        const camAngle = Math.sin(elapsed * 0.25) * 0.45;
        camera.position.set(Math.sin(camAngle) * 3.4, 1.45, Math.cos(camAngle) * 3.4);
        camera.lookAt(0, 1.18, -1.5);

        renderer.render(scene, camera);
        return;
      }

      if (phaseRef.current !== 'playing') {
        renderer.render(scene, camera);
        return;
      }

      const st = statsRef.current;
      st.survivedSeconds += dt;

      // ====================================================================
      // 1. PLAYER INPUT & MOVEMENT
      // ====================================================================
      const keys = keysRef.current;

      // Optional keyboard rotation with Q / E
      if (keys['KeyQ']) yawRef.current += 1.8 * dt;
      if (keys['KeyE'] && !st.activePromptAr) yawRef.current -= 1.8 * dt;

      let moveForward = 0;
      let moveRight = 0;
      if (keys['KeyW'] || keys['ArrowUp']) moveForward += 1;
      if (keys['KeyS'] || keys['ArrowDown']) moveForward -= 1;
      if (keys['KeyD'] || keys['ArrowRight']) moveRight += 1;
      if (keys['KeyA'] || keys['ArrowLeft']) moveRight -= 1;

      const isMovingInput = moveForward !== 0 || moveRight !== 0;
      const wantsSprint = (keys['ShiftLeft'] || keys['ShiftRight']) && isMovingInput && !st.isCrouching;

      if (wantsSprint && st.stamina > 5) {
        st.isSprinting = true;
        st.stamina = Math.max(0, st.stamina - 18 * dt);
      } else {
        st.isSprinting = false;
        st.stamina = Math.min(st.maxStamina, st.stamina + (isMovingInput ? 9 : 16) * dt);
      }

      const baseSpeed = st.isCrouching ? 2.65 : st.isSprinting ? 6.65 : 4.25;
      const forwardVec = new THREE.Vector3(-Math.sin(yawRef.current), 0, -Math.cos(yawRef.current));
      const rightVec = new THREE.Vector3(Math.cos(yawRef.current), 0, -Math.sin(yawRef.current));

      const moveVec = new THREE.Vector3();
      moveVec.addScaledVector(forwardVec, moveForward);
      moveVec.addScaledVector(rightVec, moveRight);
      if (moveVec.lengthSq() > 0) {
        moveVec.normalize().multiplyScalar(baseSpeed * dt);
        playerPosRef.current.add(moveVec);
        resolveObstacleCollisions(playerPosRef.current, 0.45);
        soundEngine.playFootstep(st.isSprinting, st.isCrouching);
      }

      // Noise level calculation
      st.noiseLevel = !isMovingInput ? 0.08 : st.isCrouching ? 0.18 : st.isSprinting ? 0.95 : 0.48;

      // ====================================================================
      // 2. FLASHLIGHT & HIGH-BEAM BURN MECHANIC
      // ====================================================================
      st.highBeamActive = highBeamHoldRef.current && st.flashlightOn && st.battery > 2;

      if (st.flashlightOn) {
        const drainRate = st.highBeamActive ? 9.5 : 1.15;
        st.battery = Math.max(0, st.battery - drainRate * dt);
        if (st.battery <= 0) {
          st.flashlightOn = false;
          st.highBeamActive = false;
          setStatusBanner('نفدت بطارية الكشاف! ابحث عن بطارية ليثيوم أو استخدم المشاعل [G]');
        }
      }

      survivorRig.flashlightSpot.visible = st.flashlightOn;
      survivorRig.flashlightConeMesh.visible = st.flashlightOn;
      survivorRig.flashlightLensMat.emissiveIntensity = st.flashlightOn
        ? st.highBeamActive
          ? 7.5
          : 3.2
        : 0.05;

      if (st.flashlightOn) {
        survivorRig.flashlightSpot.intensity = st.highBeamActive ? 14.5 : 6.2;
        survivorRig.flashlightSpot.angle = st.highBeamActive ? Math.PI * 0.13 : Math.PI * 0.24;
        survivorRig.flashlightSpot.distance = st.highBeamActive ? 58 : 44;
        survivorRig.flashlightSpot.color.setHex(st.highBeamActive ? 0xfff8e7 : 0xffe6ba);
        (survivorRig.flashlightConeMesh.material as THREE.MeshBasicMaterial).opacity = st.highBeamActive
          ? 0.15
          : 0.065;
      }

      // Update Survivor 3D Rig Position & Articulated Animation
      survivorRig.root.position.copy(playerPosRef.current);
      survivorRig.root.rotation.y = yawRef.current;
      survivorRig.headGroup.visible = st.cameraMode === 'third-person';

      animateSurvivor(
        survivorRig,
        elapsed,
        isMovingInput ? baseSpeed : 0,
        st.isSprinting,
        st.isCrouching,
        pitchRef.current,
        st.highBeamActive
      );

      survivorRimLight.position.copy(playerPosRef.current).add(new THREE.Vector3(0, 1.5, 0));

      // ====================================================================
      // 3. CAMERA PERSPECTIVE (Over-the-Shoulder 3rd-Person vs 1st-Person)
      // ====================================================================
      if (st.cameraMode === 'third-person') {
        // Tactical Over-the-Shoulder Camera (like Alan Wake II / RE4)
        // Shows the realistic 3D survivor on the left-center while keeping aiming clear
        const camBack = st.highBeamActive ? 1.85 : 2.55;
        const camHeight = st.isCrouching ? 1.28 : 1.68;
        const shoulderRightOffset = 0.52;

        const desiredCamPos = playerPosRef.current
          .clone()
          .addScaledVector(forwardVec, -camBack)
          .addScaledVector(rightVec, shoulderRightOffset);
        desiredCamPos.y += camHeight - pitchRef.current * 1.1;

        camera.position.lerp(desiredCamPos, 0.28);

        const lookTarget = playerPosRef.current
          .clone()
          .addScaledVector(forwardVec, 12)
          .addScaledVector(rightVec, 0.25);
        lookTarget.y += (st.isCrouching ? 1.1 : 1.45) + pitchRef.current * 8.5;
        camera.lookAt(lookTarget);
      } else {
        // First-Person Camera
        const eyeHeight = st.isCrouching ? 1.12 : 1.62;
        const headBob = isMovingInput
          ? Math.sin(elapsed * (st.isSprinting ? 12 : 8)) * (st.isSprinting ? 0.045 : 0.022)
          : 0;
        camera.position.set(
          playerPosRef.current.x + forwardVec.x * 0.18,
          playerPosRef.current.y + eyeHeight + headBob,
          playerPosRef.current.z + forwardVec.z * 0.18
        );
        const lookTarget = camera.position
          .clone()
          .addScaledVector(forwardVec, 10)
          .add(new THREE.Vector3(0, pitchRef.current * 7.5, 0));
        camera.lookAt(lookTarget);
      }

      // ====================================================================
      // 4. UPDATE ACTIVE FLARES ON GROUND
      // ====================================================================
      for (let i = activeFlaresRef.current.length - 1; i >= 0; i--) {
        const fl = activeFlaresRef.current[i];
        fl.remainingTime -= dt;
        // Flicker flare intensity
        fl.light.intensity = 5.5 + Math.sin(elapsed * 28 + i) * 1.4;
        if (fl.remainingTime <= 0) {
          scene.remove(fl.mesh);
          scene.remove(fl.light);
          activeFlaresRef.current.splice(i, 1);
        }
      }

      // ====================================================================
      // 5. MONSTER AI, HIGH-BEAM BURNING & REALISTIC LOCOMOTION
      // ====================================================================
      let minMonsterDist = 999;

      monstersRef.current.forEach((m) => {
        const toPlayer = new THREE.Vector3().subVectors(playerPosRef.current, m.position);
        toPlayer.y = 0;
        const distToPlayer = toPlayer.length();
        if (distToPlayer < minMonsterDist) minMonsterDist = distToPlayer;

        // Check if monster is inside an active flare safe-radius
        const nearFlare = activeFlaresRef.current.find(
          (fl) => fl.position.distanceTo(m.position) < 13.5
        );

        // Check if player's High-Beam Flashlight is burning this monster
        let isBeingBurnedByBeam = false;
        if (st.highBeamActive && distToPlayer < 26) {
          const dirToMonster = toPlayer.clone().normalize().negate(); // player -> monster
          const dot = forwardVec.dot(dirToMonster);
          if (dot > 0.86) {
            isBeingBurnedByBeam = true;
          }
        }

        if (nearFlare) {
          m.state = 'stunned';
          m.stunTimer = Math.max(m.stunTimer, 1.5);
          // Push monster away from flare
          const awayFromFlare = new THREE.Vector3()
            .subVectors(m.position, nearFlare.position)
            .setY(0)
            .normalize();
          m.position.addScaledVector(awayFromFlare, m.speedChase * 0.85 * dt);
        } else if (isBeingBurnedByBeam) {
          m.burnExposure += dt * 1.9;
          m.joints.eyesMaterial.emissiveIntensity = 8.0;
          if (m.burnExposure >= 1.15 && m.state !== 'stunned') {
            m.state = 'stunned';
            m.stunTimer = 3.6;
            m.burnExposure = 0;
            st.monstersRepelled += 1;
            soundEngine.playMonsterGrowl(m.archetype, distToPlayer, true);
            setStatusBanner(`تم حرق وصعق ${m.nameAr} بالشعاع المركز!`);
          }
        } else {
          m.burnExposure = Math.max(0, m.burnExposure - dt * 0.5);
          m.joints.eyesMaterial.emissiveIntensity = m.state === 'chase' ? 4.8 : 2.8;
        }

        if (m.attackCooldown > 0) m.attackCooldown -= dt;

        // State machine
        let isMonsterMoving = false;
        if (m.state === 'stunned') {
          m.stunTimer -= dt;
          // Stagger backward away from player
          const away = toPlayer.clone().normalize().negate();
          m.position.addScaledVector(away, 2.2 * dt);
          isMonsterMoving = true;
          if (m.stunTimer <= 0) {
            m.state = 'patrol';
            // Pick a patrol point further away so player has breathing room
            const randomAngle = Math.random() * Math.PI * 2;
            m.patrolTarget.set(
              playerPosRef.current.x + Math.cos(randomAngle) * 38,
              0,
              playerPosRef.current.z + Math.sin(randomAngle) * 38
            );
          }
        } else {
          // Detection radius depends on player crouch, sprint noise, and flashlight
          const effectiveDetectRadius =
            m.detectionRadius *
            (st.isCrouching ? 0.55 : st.isSprinting ? 1.35 : 1.0) *
            (st.flashlightOn ? 1.15 : 0.72) *
            (difficultyRef.current === 'hardcore' ? 1.2 : 1.0);

          if (distToPlayer < effectiveDetectRadius) {
            if (m.state !== 'chase') {
              m.state = 'chase';
              soundEngine.playMonsterGrowl(m.archetype, distToPlayer, false);
            }
          } else if (m.state === 'chase' && distToPlayer > effectiveDetectRadius * 1.45) {
            m.state = 'patrol';
          }

          if (m.state === 'chase') {
            isMonsterMoving = true;
            const dir = toPlayer.clone().normalize();
            const chaseSpeed =
              m.speedChase * (difficultyRef.current === 'hardcore' ? 1.12 : 0.96);

            if (distToPlayer > 1.75) {
              m.position.addScaledVector(dir, chaseSpeed * dt);
            } else if (m.attackCooldown <= 0) {
              // Monster strikes player!
              m.attackCooldown = 1.65;
              st.health = Math.max(0, st.health - m.attackDamage);
              soundEngine.playPlayerHit();
              soundEngine.playMonsterGrowl(m.archetype, distToPlayer, false);
              setStatusBanner(`تحذير! تعرضت لهجوم مباشر من ${m.nameAr}!`);

              if (st.health <= 0) {
                setGamePhase('gameover');
                phaseRef.current = 'gameover';
                if (document.pointerLockElement) document.exitPointerLock?.();
              }
            }

            m.rotationY = Math.atan2(-dir.x, -dir.z);

            // Periodic terrifying growls during chase
            if (elapsed - m.lastGrowlTime > 4.5) {
              m.lastGrowlTime = elapsed;
              soundEngine.playMonsterGrowl(m.archetype, distToPlayer, false);
            }
          } else {
            // Patrol behavior
            const toPatrol = new THREE.Vector3().subVectors(m.patrolTarget, m.position);
            toPatrol.y = 0;
            if (toPatrol.length() < 2.5) {
              const ang = Math.random() * Math.PI * 2;
              const rad = 22 + Math.random() * 55;
              m.patrolTarget.set(Math.cos(ang) * rad, 0, Math.sin(ang) * rad);
            } else {
              isMonsterMoving = true;
              const dir = toPatrol.normalize();
              m.position.addScaledVector(dir, m.speedPatrol * dt);
              m.rotationY = Math.atan2(-dir.x, -dir.z);
            }
          }
        }

        resolveObstacleCollisions(m.position, 0.55);
        m.meshGroup.position.copy(m.position);
        m.meshGroup.rotation.y = m.rotationY;

        animateMonster(m, dt, isMonsterMoving);
      });

      st.nearestMonsterDist = minMonsterDist;
      st.dangerLevel = THREE.MathUtils.clamp(1 - minMonsterDist / 32, 0, 1);
      st.heartbeatBpm = THREE.MathUtils.lerp(
        st.heartbeatBpm,
        72 + st.dangerLevel * 92 + (st.isSprinting ? 24 : 0),
        0.1
      );
      soundEngine.updateHeartbeat(st.heartbeatBpm, st.dangerLevel);

      // ====================================================================
      // 6. INTERACTABLES: RADIO BEACONS, SUPPLIES, AND EXTRACTION ZONE
      // ====================================================================
      let promptAr: string | null = null;

      // Check Collectibles (auto-pickup when close or press E)
      collectiblesRef.current.forEach((item) => {
        if (item.collected) return;
        item.mesh.rotation.y = elapsed * 1.6;
        item.mesh.position.y = 0.35 + Math.sin(elapsed * 3) * 0.08;

        const dist = playerPosRef.current.distanceTo(item.position);
        if (dist < 2.6) {
          promptAr = `اضغط [E] لالتقاط ${item.labelAr}`;
          if (interactHoldRef.current || dist < 1.35) {
            item.collected = true;
            item.mesh.visible = false;
            soundEngine.playPickupChime();

            if (item.type === 'battery') {
              st.battery = Math.min(st.maxBattery, st.battery + 55);
              st.flashlightOn = true;
              setStatusBanner('تم شحن بطارية الكشاف التكتيكي (+55%)');
            } else if (item.type === 'flare') {
              st.flaresCount += 2;
              setStatusBanner('تم الحصول على مشاعل ماغنيسيوم حرارية (+2)');
            } else if (item.type === 'medkit') {
              st.medkitsCount += 1;
              setStatusBanner('تم الحصول على حقيبة إسعافات ميدانية (+1)');
            } else if (item.type === 'note' && item.noteTextAr) {
              st.collectedNotes.push(item.noteTextAr);
              setLatestNotePopup(item.noteTextAr);
              setStatusBanner(`تم العثور على وثيقة: ${item.labelAr}`);
            }
            interactHoldRef.current = false;
          }
        }
      });

      // Check Radio Beacons
      beaconsRef.current.forEach((beacon) => {
        if (beacon.activated) return;
        const dist = playerPosRef.current.distanceTo(beacon.position);
        if (dist < 3.8) {
          promptAr = `اضغط مطولاً على [E] لتفعيل ${beacon.nameAr} (${Math.round(
            beacon.activationProgress
          )}%)`;
          if (interactHoldRef.current) {
            beacon.activationProgress = Math.min(100, beacon.activationProgress + 38 * dt);
            if (beacon.activationProgress >= 100) {
              beacon.activated = true;
              beacon.beaconLight.color.setHex(0x38b566);
              beacon.beaconLight.intensity = 4.5;
              beacon.statusLampMat.color.setHex(0x38b566);
              beacon.statusLampMat.emissive.setHex(0x22c55e);

              st.beaconsActivated += 1;
              soundEngine.playBeaconActivated();

              if (st.beaconsActivated >= st.totalBeacons) {
                st.extractionReady = true;
                if (extractionZoneRef.current) {
                  extractionZoneRef.current.floodLight.intensity = 8.5;
                  (
                    extractionZoneRef.current.beaconColumn.material as THREE.MeshBasicMaterial
                  ).opacity = 0.22;
                }
                setStatusBanner(
                  'تم تفعيل جميع الأبراج! مروحية الإنقاذ بانتظارك في منطقة الإخلاء شمالاً!'
                );
              } else {
                setStatusBanner(
                  `تم تفعيل ${beacon.nameAr} بنجاح! (${st.beaconsActivated}/${st.totalBeacons})`
                );
              }
            }
          }
        }
      });

      // Check Northern Extraction Zone when ready
      if (st.extractionReady && extractionZoneRef.current) {
        const distToExt = playerPosRef.current.distanceTo(extractionZoneRef.current.position);
        if (distToExt < extractionZoneRef.current.radius) {
          promptAr = `قف داخل دائرة الإخلاء لتأكيد الإنقاذ (${Math.round(st.extractionProgress)}%)`;
          st.extractionProgress = Math.min(100, st.extractionProgress + 28 * dt);
          if (st.extractionProgress >= 100) {
            soundEngine.playBeaconActivated();
            setGamePhase('victory');
            phaseRef.current = 'victory';
            if (document.pointerLockElement) document.exitPointerLock?.();
          }
        }
      }

      st.activePromptAr = promptAr;

      // Convert yaw to compass heading degrees (0 = North, 90 = East, 180 = South, 270 = West)
      const deg = ((-THREE.MathUtils.radToDeg(yawRef.current) % 360) + 360) % 360;
      st.headingDeg = deg;

      // Sync React HUD state at ~15Hz for smooth performance
      hudSyncAccumulator += dt;
      if (hudSyncAccumulator > 0.065) {
        hudSyncAccumulator = 0;
        setStats({ ...st });

        // Compute compass markers relative to player position
        const markers: CompassMarker[] = [];
        beaconsRef.current.forEach((b) => {
          const dx = b.position.x - playerPosRef.current.x;
          const dz = b.position.z - playerPosRef.current.z;
          const angleDeg = ((THREE.MathUtils.radToDeg(Math.atan2(dx, -dz)) % 360) + 360) % 360;
          markers.push({
            id: b.id,
            labelAr: b.nameAr,
            type: 'beacon',
            angleDeg,
            distance: Math.hypot(dx, dz),
            activated: b.activated,
          });
        });

        if (st.extractionReady && extractionZoneRef.current) {
          const ex = extractionZoneRef.current.position;
          const dx = ex.x - playerPosRef.current.x;
          const dz = ex.z - playerPosRef.current.z;
          const angleDeg = ((THREE.MathUtils.radToDeg(Math.atan2(dx, -dz)) % 360) + 360) % 360;
          markers.push({
            id: 'extraction',
            labelAr: 'منطقة الإخلاء',
            type: 'extraction',
            angleDeg,
            distance: Math.hypot(dx, dz),
          });
        }

        monstersRef.current.forEach((m) => {
          const dx = m.position.x - playerPosRef.current.x;
          const dz = m.position.z - playerPosRef.current.z;
          const dist = Math.hypot(dx, dz);
          if (dist < 42) {
            const angleDeg = ((THREE.MathUtils.radToDeg(Math.atan2(dx, -dz)) % 360) + 360) % 360;
            markers.push({
              id: m.id,
              labelAr: m.nameAr,
              type: 'monster',
              angleDeg,
              distance: dist,
            });
          }
        });

        setCompassMarkers(markers);
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('contextmenu', onContextMenu);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, [
    handleThrowFlare,
    handleToggleCamera,
    handleToggleCrouch,
    handleToggleFlashlight,
    handleUseMedkit,
    setStatusBanner,
  ]);

  const toggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    soundEngine.setMuted(next);
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#070B0A] select-none">
      {/* Full-Viewport 3D WebGL Canvas */}
      <div ref={canvasContainerRef} className="fixed inset-0 w-full h-full z-0" />

      {/* Active Gameplay HUD */}
      {gamePhase === 'playing' && (
        <>
          <TacticalHUD
            stats={stats}
            compassMarkers={compassMarkers}
            isMuted={isMuted}
            onToggleMute={toggleMute}
            onToggleCamera={handleToggleCamera}
            onToggleFlashlight={handleToggleFlashlight}
            onTriggerHighBeam={(active) => {
              highBeamHoldRef.current = active;
            }}
            onThrowFlare={handleThrowFlare}
            onUseMedkit={handleUseMedkit}
            onToggleCrouch={handleToggleCrouch}
            onInteractHold={(holding) => {
              interactHoldRef.current = holding;
            }}
            onOpenInspector={() => setShowInspector(true)}
            onPause={() => setGamePhase('paused')}
          />

          {/* Field Journal / Lore Popup Toast when discovered */}
          {latestNotePopup && (
            <div className="fixed top-24 right-5 z-30 max-w-sm tactical-panel-amber p-4 rounded-xl animate-fade-in pointer-events-auto">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold text-[#D9822B] flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4" />
                  مذكرة ميدانية مكتشفة
                </span>
                <button
                  onClick={() => setLatestNotePopup(null)}
                  className="text-xs text-[#8A9E93] hover:text-white cursor-pointer"
                >
                  إغلاق ✕
                </button>
              </div>
              <p className="text-xs text-[#E6ECE8] leading-relaxed">{latestNotePopup}</p>
            </div>
          )}
        </>
      )}

      {/* ====================================================================
          TITLE SCREEN OVERLAY (Rendered over Live 3D Forest Scene)
         ==================================================================== */}
      {gamePhase === 'title' && (
        <div className="fixed inset-0 z-30 flex items-center justify-between p-6 sm:p-12 bg-gradient-to-l from-[#070B0A]/90 via-[#070B0A]/55 to-transparent">
          <div className="max-w-xl w-full tactical-panel p-7 sm:p-9 rounded-2xl border border-[#8A9E93]/25 shadow-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D9822B]/15 border border-[#D9822B]/40 text-[#D9822B] text-xs font-bold mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              <span>تجربة رعب وبقاء ثلاثية الأبعاد بملامح واقعية</span>
            </div>

            <h1 className="text-4xl sm:text-5xl font-black text-[#E6ECE8] tracking-tight leading-tight mb-3">
              وادي الظلام: <span className="text-[#D9822B]">نجاة المفقود</span>
            </h1>

            <p className="text-sm sm:text-base text-[#8A9E93] leading-relaxed mb-6">
              تحطمت مركبة الاستطلاع الخاصة بك في أعماق غابة موحشة يعود تاريخها لقرون. أنت تلعب بشخصية{' '}
              <strong className="text-[#E6ECE8]">«آدم المنصور»</strong>؛ مسلحاً فقط بكشافك التكتيكي
              ومشاعل الماغنيسيوم الحرارية. فعّل أبراج الإشارة الأربعة لطلب مروحية الإنقاذ قبل أن
              تفتك بك وحوش الغابة.
            </p>

            {/* Difficulty selector */}
            <div className="mb-6">
              <div className="text-xs font-bold text-[#8A9E93] mb-2">مستوى صعوبة البقاء:</div>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setDifficulty('normal')}
                  className={`p-3 rounded-xl border text-right transition cursor-pointer ${
                    difficulty === 'normal'
                      ? 'bg-[#D9822B]/20 border-[#D9822B] text-[#E6ECE8]'
                      : 'bg-white/5 border-white/10 text-[#8A9E93] hover:bg-white/10'
                  }`}
                >
                  <div className="text-sm font-bold">الوضع التكتيكي (موصى به)</div>
                  <div className="text-[11px] opacity-80 mt-0.5">
                    ٣ مشاعل حرارية • بطارية متوازنة •٥ وحوش في الغابة
                  </div>
                </button>
                <button
                  onClick={() => setDifficulty('hardcore')}
                  className={`p-3 rounded-xl border text-right transition cursor-pointer ${
                    difficulty === 'hardcore'
                      ? 'bg-[#C93B2B]/20 border-[#C93B2B] text-[#E6ECE8]'
                      : 'bg-white/5 border-white/10 text-[#8A9E93] hover:bg-white/10'
                  }`}
                >
                  <div className="text-sm font-bold text-[#f87171]">كابوس الغابة (واقعي قاسٍ)</div>
                  <div className="text-[11px] opacity-80 mt-0.5">
                    موارد نادرة • مدى استشعار أعلى للوحوش • ٢ وينديغو
                  </div>
                </button>
              </div>
            </div>

            {/* Primary CTAs */}
            <div className="flex flex-col sm:flex-row gap-3 mb-6">
              <button
                onClick={() => resetOrStartGame(difficulty)}
                className="flex-1 py-3.5 px-6 rounded-xl bg-[#D9822B] hover:bg-[#e6923a] text-black font-extrabold text-base shadow-[0_0_25px_rgba(217,130,43,0.4)] transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Play className="w-5 h-5 fill-current" />
                <span>ابدأ رحلة النجاة الآن</span>
              </button>

              <button
                onClick={() => setShowInspector(true)}
                className="py-3.5 px-5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/20 text-[#E6ECE8] font-bold text-sm transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Eye className="w-4 h-4 text-[#D9822B]" />
                <span>فحص الشخصيات والوحوش 3D</span>
              </button>
            </div>

            {/* Key Controls Summary Card */}
            <div className="bg-black/45 border border-white/10 rounded-xl p-4">
              <div className="text-xs font-bold text-[#D9822B] mb-2.5 flex items-center gap-1.5">
                <Compass className="w-4 h-4" />
                <span>دليل التحكم السريع:</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
                <div className="flex items-center gap-2">
                  <kbd className="px-2 py-0.5 bg-white/10 rounded font-mono-tech text-[#E6ECE8]">
                    WASD
                  </kbd>
                  <span className="text-[#8A9E93]">الحركة والمشي</span>
                </div>
                <div className="flex items-center gap-2">
                  <kbd className="px-2 py-0.5 bg-white/10 rounded font-mono-tech text-[#E6ECE8]">
                    Shift
                  </kbd>
                  <span className="text-[#8A9E93]">ركض سريع</span>
                </div>
                <div className="flex items-center gap-2">
                  <kbd className="px-2 py-0.5 bg-white/10 rounded font-mono-tech text-[#E6ECE8]">
                    Space
                  </kbd>
                  <span className="text-[#8A9E93]">شعاع حارق للوحوش</span>
                </div>
                <div className="flex items-center gap-2">
                  <kbd className="px-2 py-0.5 bg-white/10 rounded font-mono-tech text-[#E6ECE8]">
                    G
                  </kbd>
                  <span className="text-[#8A9E93]">رمي مشعل ناري</span>
                </div>
                <div className="flex items-center gap-2">
                  <kbd className="px-2 py-0.5 bg-white/10 rounded font-mono-tech text-[#E6ECE8]">
                    C / F
                  </kbd>
                  <span className="text-[#8A9E93]">تسلل / الكشاف</span>
                </div>
                <div className="flex items-center gap-2">
                  <kbd className="px-2 py-0.5 bg-white/10 rounded font-mono-tech text-[#E6ECE8]">
                    V / E
                  </kbd>
                  <span className="text-[#8A9E93]">الكاميرا / تفاعل</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ====================================================================
          PAUSE MENU MODAL
         ==================================================================== */}
      {gamePhase === 'paused' && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="tactical-panel max-w-md w-full p-7 rounded-2xl text-center border border-white/15">
            <h2 className="text-2xl font-black text-[#E6ECE8] mb-2">اللعبة متوقفة مؤقتاً</h2>
            <p className="text-xs text-[#8A9E93] mb-6">
              الأبراج المفعّلة: {stats.beaconsActivated} من {stats.totalBeacons} • الوقت المنقضي:{' '}
              {Math.floor(stats.survivedSeconds)} ثانية
            </p>

            <div className="space-y-3">
              <button
                onClick={() => setGamePhase('playing')}
                className="w-full py-3 rounded-xl bg-[#D9822B] hover:bg-[#e59038] text-black font-bold text-sm transition cursor-pointer"
              >
                استئناف اللعب
              </button>
              <button
                onClick={() => setShowInspector(true)}
                className="w-full py-3 rounded-xl bg-white/10 hover:bg-white/15 text-[#E6ECE8] font-bold text-sm transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Eye className="w-4 h-4 text-[#D9822B]" />
                <span>فحص نماذج الشخصيات والوحوش 3D</span>
              </button>
              <button
                onClick={() => resetOrStartGame(difficulty)}
                className="w-full py-3 rounded-xl bg-white/5 hover:bg-white/10 text-[#8A9E93] hover:text-white font-bold text-sm transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>إعادة المهمة من البداية</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ====================================================================
          GAME OVER MODAL
         ==================================================================== */}
      {gamePhase === 'gameover' && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-[#1a0505]/90 backdrop-blur-md p-4">
          <div className="tactical-panel max-w-md w-full p-8 rounded-2xl text-center border border-[#C93B2B]/50">
            <div className="w-16 h-16 rounded-full bg-[#C93B2B]/20 border border-[#C93B2B] flex items-center justify-center mx-auto mb-4">
              <ShieldAlert className="w-8 h-8 text-[#C93B2B]" />
            </div>
            <h2 className="text-3xl font-black text-[#E6ECE8] mb-2">ابتلعتك ظلمات الغابة</h2>
            <p className="text-sm text-[#8A9E93] mb-6 leading-relaxed">
              تمكنت وحوش الوادي من محاصرتك قبل وصول مروحية الإخلاء. تذكر استخدام الشعاع الحارق{' '}
              <span className="text-[#D9822B] font-bold">[Space]</span> والمشاعل الحرارية{' '}
              <span className="text-[#D9822B] font-bold">[G]</span> لصعق الوحوش عند اقترابها!
            </p>

            <div className="grid grid-cols-3 gap-2 mb-6 bg-black/40 p-3 rounded-xl border border-white/10 text-xs">
              <div>
                <div className="text-[#8A9E93]">الأبراج المفعلة</div>
                <div className="text-base font-bold text-[#E6ECE8] font-mono-tech">
                  {stats.beaconsActivated}/{stats.totalBeacons}
                </div>
              </div>
              <div>
                <div className="text-[#8A9E93]">وحوش تم ردعها</div>
                <div className="text-base font-bold text-[#D9822B] font-mono-tech">
                  {stats.monstersRepelled}
                </div>
              </div>
              <div>
                <div className="text-[#8A9E93]">مدة الصمود</div>
                <div className="text-base font-bold text-[#E6ECE8] font-mono-tech">
                  {Math.floor(stats.survivedSeconds)}ث
                </div>
              </div>
            </div>

            <button
              onClick={() => resetOrStartGame(difficulty)}
              className="w-full py-3.5 rounded-xl bg-[#D9822B] hover:bg-[#e59038] text-black font-extrabold text-sm transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>محاولة النجاة مجدداً</span>
            </button>
          </div>
        </div>
      )}

      {/* ====================================================================
          VICTORY EXTRACTION MODAL
         ==================================================================== */}
      {gamePhase === 'victory' && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-[#061810]/90 backdrop-blur-md p-4">
          <div className="tactical-panel max-w-lg w-full p-8 rounded-2xl text-center border border-[#38B566]/50">
            <div className="w-16 h-16 rounded-full bg-[#38B566]/20 border border-[#38B566] flex items-center justify-center mx-auto mb-4">
              <Trophy className="w-8 h-8 text-[#38B566]" />
            </div>
            <h2 className="text-3xl font-black text-[#E6ECE8] mb-2">نجوت من غابة الظلام!</h2>
            <p className="text-sm text-[#8A9E93] mb-6 leading-relaxed">
              بعد تفعيل أبراج الإشارة الأربعة والصمود أمام «حارس القرون» والمترصدين، هبطت مروحية
              الإنقاذ في القطاع الشمالي وتم إخلاؤك بسلام!
            </p>

            <div className="grid grid-cols-3 gap-3 mb-6 bg-black/45 p-4 rounded-xl border border-white/10 text-xs">
              <div>
                <div className="text-[#8A9E93]">زمن النجاة</div>
                <div className="text-lg font-bold text-[#38B566] font-mono-tech">
                  {Math.floor(stats.survivedSeconds)} ثانية
                </div>
              </div>
              <div>
                <div className="text-[#8A9E93]">وحوش تم صعقها</div>
                <div className="text-lg font-bold text-[#D9822B] font-mono-tech">
                  {stats.monstersRepelled}
                </div>
              </div>
              <div>
                <div className="text-[#8A9E93]">الصحة المتبقية</div>
                <div className="text-lg font-bold text-[#E6ECE8] font-mono-tech">
                  {Math.ceil(stats.health)}%
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => resetOrStartGame('hardcore')}
                className="flex-1 py-3.5 rounded-xl bg-[#D9822B] hover:bg-[#e59038] text-black font-extrabold text-sm transition cursor-pointer"
              >
                العب طور الكابوس
              </button>
              <button
                onClick={() => setGamePhase('title')}
                className="py-3.5 px-5 rounded-xl bg-white/10 hover:bg-white/15 text-[#E6ECE8] font-bold text-sm transition cursor-pointer"
              >
                القائمة الرئيسية
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3D Character & Monster Realism Studio Modal */}
      {showInspector && <CharacterInspectorModal onClose={() => setShowInspector(false)} />}
    </div>
  );
}

export default App;
