import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { X, RotateCcw, Eye, ShieldAlert, Zap, Flame } from 'lucide-react';
import {
  animateMonster,
  animateSurvivor,
  buildMonsterCharacter,
  buildSurvivorCharacter,
} from '../game/characterModels';
import { MonsterArchetype } from '../game/types';

interface CharacterInspectorModalProps {
  onClose: () => void;
}

type InspectSubject = 'survivor' | MonsterArchetype;

interface SubjectInfo {
  id: InspectSubject;
  titleAr: string;
  subtitleAr: string;
  heightAr: string;
  dangerAr: string;
  descriptionAr: string;
  weaknessAr: string;
  anatomicalNotesAr: string[];
}

const SUBJECTS: SubjectInfo[] = [
  {
    id: 'survivor',
    titleAr: 'آدم المنصور (الناجي المفقود)',
    subtitleAr: 'مهندس اتصالات ميداني - بعثة استطلاع وادي الظلام',
    heightAr: '١.٨٢ متر',
    dangerAr: 'ناجٍ بشري',
    descriptionAr:
      'الناجي الوحيد بعد تحطم مركبة الاستطلاع في وادي الظلام. يرتدي سترة ميدانية مقاومة للبلل وحقيبة ظهر مجهزة بجهاز إرسال لاسلكي وكشاف تكتيكي عالي التركيز ومشاعل ماغنيسيوم حرارية.',
    weaknessAr: 'يعتمد على طاقة البطارية والمشاعل للبقاء حياً، ويصدر ضوضاء عند الركض السريع.',
    anatomicalNotesAr: [
      'بنية جسدية بشرية واقعية مع مفاصل كاملة (الكتفين، المرفقين، الحوض، الركبتين، الكاحلين).',
      'خامة بشرة طبيعية مع ملامح الوجه واللحية وسترة ميدانية متسخة بطين الغابة.',
      'كشاف تكتيكي بضوء حجمي (Volumetric SpotLight) مع وضع الشعاع الحارق.',
    ],
  },
  {
    id: 'wendigo',
    titleAr: 'حارس القرون (الوينديغو العتيق)',
    subtitleAr: 'المفترس الأعلى في غابة الظلام',
    heightAr: '٢.٩٥ متر',
    dangerAr: 'خطر قاتل جداً',
    descriptionAr:
      'كائن عملاق هجين بين البنية البشرية المتوحشة وجمجمة الأيل المتكلسة ذات القرون المتفرعة. يهتز الأديم تحت خطواته الثقيلة ويمتلك مدى رصد واسع في الظلام.',
    weaknessAr: 'يتأثر بشدة بالمشاعل الضوئية الحرارية [G] والشعاع العالي المركز على عينيه.',
    anatomicalNotesAr: [
      'جمجمة عظمية متآكلة مع قرون متفرعة وفك سفلي متحرك بأنياب حادة.',
      'قفص صدري بارز وعمود فقري مسنن مع جلد عضوي رطب يعكس ضوء الكشاف.',
      'أطراف أمامية طويلة تنتهي بمخالب عظمية منحنية للفتك بالفريسة.',
    ],
  },
  {
    id: 'stalker',
    titleAr: 'المترصد الليلي (صائد الظلال)',
    subtitleAr: 'مفترس ليلي صامت يتعقب الصوت والضوء',
    heightAr: '٢.٣٠ متر',
    dangerAr: 'خطر مرتفع',
    descriptionAr:
      'كائن هزيل طويل القامة يتحرك بانحناءة مفترسة بين الأشجار الكثيفة. يراقب الضحية من بعيد بعيونه الكهرمانية المتوهجة قبل أن ينقض بسرعة خاطفة.',
    weaknessAr: 'توجيه الشعاع العالي للكشاف (الضغط المطول على المسافة أو الزر الأيمن) يحرق شبكيته ويجبره على التراجع.',
    anatomicalNotesAr: [
      'عضلات مشدودة وأوردة داكنة بارزة تحت جلد رمادي شاحب.',
      'حركة مفصلية تحاكي الكائنات المفترسة الليلية مع استجابة فورية للضوء الساطع.',
      'عيون غائرة عالية التوهج تكشف موقعه بين الضباب الكثيف.',
    ],
  },
  {
    id: 'creeper',
    titleAr: 'عدّاء الضباب (الزاحف الشاحب)',
    subtitleAr: 'مفترس سريع يطوق الضحية من الخلف',
    heightAr: '١.٩٥ متر (منحنٍ)',
    dangerAr: 'سريع ومباغت',
    descriptionAr:
      'أسرع كائنات الغابة حركةً؛ يندفع عبر الضباب المنخفض بوضعية منخفضة لمباغتة الناجين أثناء تفعيلهم لأبراج الإشارة اللاسلكية.',
    weaknessAr: 'بنيته الجسدية أضعف من الوينديغو؛ يُصعق بسرعة عند إشعال مشعل ضوئي أو تركيز الكشاف عليه.',
    anatomicalNotesAr: [
      'انحناءة ظهر حادة تمنحه سرعة انقضاض عالية بين الأعشاب والصخور.',
      'عيون فسفورية خضراء تتوهج في العتمة العميقة.',
      'حركة أطراف سريعة ومضطربة تزيد من التوتر النفسي.',
    ],
  },
];

export const CharacterInspectorModal: React.FC<CharacterInspectorModalProps> = ({ onClose }) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [selected, setSelected] = useState<InspectSubject>('survivor');
  const [animMode, setAnimMode] = useState<'idle' | 'walk' | 'sprint' | 'stun'>('walk');
  const rotationYRef = useRef<number>(0.45);
  const isDraggingRef = useRef<boolean>(false);
  const lastMouseXRef = useRef<number>(0);

  const currentInfo = SUBJECTS.find((s) => s.id === selected) || SUBJECTS[0];

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 600;
    const height = container.clientHeight || 480;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x080d0b);
    scene.fog = new THREE.FogExp2(0x080d0b, 0.08);

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 50);
    camera.position.set(0, 1.45, 3.65);
    camera.lookAt(0, 1.15, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Three-point dramatic studio lighting to highlight realistic anatomy & textures
    const ambient = new THREE.AmbientLight(0x283832, 1.3);
    scene.add(ambient);

    const keyLight = new THREE.DirectionalLight(0xffe6c2, 2.8);
    keyLight.position.set(2.5, 4.2, 3.2);
    keyLight.castShadow = true;
    scene.add(keyLight);

    const rimLight = new THREE.SpotLight(0x4fa88a, 4.2, 12, Math.PI * 0.35, 0.5);
    rimLight.position.set(-2.6, 3.4, -2.8);
    scene.add(rimLight);

    const warmFill = new THREE.PointLight(0xd9822b, 1.5, 8);
    warmFill.position.set(-2.0, 1.1, 2.2);
    scene.add(warmFill);

    // Circular Forest Pedestal
    const pedestal = new THREE.Mesh(
      new THREE.CylinderGeometry(1.15, 1.28, 0.16, 32),
      new THREE.MeshStandardMaterial({ color: 0x16211c, roughness: 0.8, metalness: 0.2 })
    );
    pedestal.position.y = -0.08;
    pedestal.receiveShadow = true;
    scene.add(pedestal);

    const ring = new THREE.Mesh(
      new THREE.RingGeometry(1.08, 1.13, 32),
      new THREE.MeshBasicMaterial({ color: 0xd9822b, side: THREE.DoubleSide })
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.005;
    scene.add(ring);

    // Build selected 3D character
    const turntable = new THREE.Group();
    scene.add(turntable);

    let survivorRig: ReturnType<typeof buildSurvivorCharacter> | null = null;
    let monsterEntity: ReturnType<typeof buildMonsterCharacter> | null = null;

    if (selected === 'survivor') {
      survivorRig = buildSurvivorCharacter();
      // Rotate model so it faces camera (+Z)
      survivorRig.root.rotation.y = Math.PI;
      turntable.add(survivorRig.root);
      camera.position.set(0, 1.32, 3.25);
      camera.lookAt(0, 1.05, 0);
    } else {
      monsterEntity = buildMonsterCharacter('preview', selected, new THREE.Vector3(0, 0, 0));
      monsterEntity.meshGroup.rotation.y = Math.PI;
      turntable.add(monsterEntity.meshGroup);
      const camZ = selected === 'wendigo' ? 4.35 : 3.65;
      const camY = selected === 'wendigo' ? 1.65 : 1.35;
      camera.position.set(0, camY, camZ);
      camera.lookAt(0, camY * 0.82, 0);
    }

    let animFrameId = 0;
    const clock = new THREE.Clock();

    const animate = () => {
      animFrameId = requestAnimationFrame(animate);
      const dt = clock.getDelta();
      const elapsed = clock.getElapsedTime();

      if (!isDraggingRef.current) {
        rotationYRef.current += dt * 0.35;
      }
      turntable.rotation.y = rotationYRef.current;

      if (survivorRig) {
        const speed = animMode === 'idle' ? 0 : animMode === 'sprint' ? 5 : 2.5;
        animateSurvivor(
          survivorRig,
          elapsed,
          speed,
          animMode === 'sprint',
          animMode === 'stun',
          0,
          animMode === 'sprint'
        );
      } else if (monsterEntity) {
        monsterEntity.state =
          animMode === 'stun' ? 'stunned' : animMode === 'sprint' ? 'chase' : 'patrol';
        animateMonster(monsterEntity, dt, animMode !== 'idle');
      }

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);
    return () => {
      cancelAnimationFrame(animFrameId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, [selected, animMode]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="tactical-panel w-full max-w-5xl rounded-xl overflow-hidden border border-[#8A9E93]/30 flex flex-col md:flex-row max-h-[90vh]">
        {/* Right side (RTL): Character Selection & Anatomical Lore */}
        <div className="w-full md:w-5/12 p-6 flex flex-col justify-between bg-[#090F0D]/95 border-l border-[#8A9E93]/15 overflow-y-auto">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold tracking-wider text-[#D9822B] bg-[#D9822B]/10 px-2.5 py-1 rounded border border-[#D9822B]/30">
                استوديو فحص الواقعية 3D
              </span>
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[#8A9E93] hover:text-white transition cursor-pointer"
                title="إغلاق"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <h2 className="text-2xl font-bold text-[#E6ECE8] mb-1">{currentInfo.titleAr}</h2>
            <p className="text-sm text-[#8A9E93] mb-4">{currentInfo.subtitleAr}</p>

            {/* Subject switcher tabs */}
            <div className="grid grid-cols-2 gap-2 mb-5">
              {SUBJECTS.map((subj) => (
                <button
                  key={subj.id}
                  onClick={() => setSelected(subj.id)}
                  className={`px-3 py-2 rounded-lg text-right text-xs font-bold transition cursor-pointer border ${
                    selected === subj.id
                      ? 'bg-[#D9822B]/20 border-[#D9822B] text-[#E6ECE8]'
                      : 'bg-white/5 border-white/10 text-[#8A9E93] hover:bg-white/10'
                  }`}
                >
                  {subj.titleAr.split(' (')[0]}
                </button>
              ))}
            </div>

            {/* Specs badges */}
            <div className="grid grid-cols-2 gap-2.5 mb-4">
              <div className="bg-black/40 border border-white/10 rounded-lg p-2.5">
                <div className="text-[11px] text-[#8A9E93]">الطول التقديري</div>
                <div className="text-sm font-bold text-[#E6ECE8]">{currentInfo.heightAr}</div>
              </div>
              <div className="bg-black/40 border border-white/10 rounded-lg p-2.5">
                <div className="text-[11px] text-[#8A9E93]">تصنيف التهديد</div>
                <div className="text-sm font-bold text-[#D9822B]">{currentInfo.dangerAr}</div>
              </div>
            </div>

            <p className="text-sm text-[#E6ECE8]/90 leading-relaxed mb-4 bg-white/[0.03] p-3 rounded-lg border border-white/5">
              {currentInfo.descriptionAr}
            </p>

            <div className="mb-4">
              <h3 className="text-xs font-bold text-[#D9822B] uppercase mb-2 flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5" />
                التفاصيل التشريحية والواقعية:
              </h3>
              <ul className="space-y-1.5 text-xs text-[#8A9E93]">
                {currentInfo.anatomicalNotesAr.map((note, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-[#D9822B] mt-0.5">•</span>
                    <span>{note}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-[#C93B2B]/10 border border-[#C93B2B]/30 rounded-lg p-3">
              <div className="text-xs font-bold text-[#f87171] mb-1 flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4" />
                نقطة الضعف والتكتيك:
              </div>
              <p className="text-xs text-[#E6ECE8]/90 leading-relaxed">{currentInfo.weaknessAr}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="mt-5 w-full py-2.5 rounded-lg bg-[#D9822B] hover:bg-[#e5923b] text-black font-bold text-sm transition cursor-pointer"
          >
            العودة إلى الغابة
          </button>
        </div>

        {/* Left side (RTL): Interactive 3D Viewport */}
        <div className="w-full md:w-7/12 relative min-h-[380px] md:min-h-[520px] bg-[#070B0A] flex flex-col">
          <div
            ref={mountRef}
            onMouseDown={(e) => {
              isDraggingRef.current = true;
              lastMouseXRef.current = e.clientX;
            }}
            onMouseMove={(e) => {
              if (!isDraggingRef.current) return;
              const delta = e.clientX - lastMouseXRef.current;
              lastMouseXRef.current = e.clientX;
              rotationYRef.current += delta * 0.012;
            }}
            onMouseUp={() => {
              isDraggingRef.current = false;
            }}
            onMouseLeave={() => {
              isDraggingRef.current = false;
            }}
            className="flex-1 w-full h-full cursor-grab active:cursor-grabbing"
          />

          {/* Viewport overlay controls */}
          <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none">
            <div className="bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 text-xs text-[#8A9E93] flex items-center gap-2">
              <RotateCcw className="w-3.5 h-3.5 text-[#D9822B]" />
              اسحب بالماوس لتدوير المجسم 360°
            </div>
          </div>

          {/* Animation state controls */}
          <div className="p-3 bg-[#090F0D]/90 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs text-[#8A9E93] font-medium">اختبار الحركة المفصلية:</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setAnimMode('idle')}
                className={`px-3 py-1.5 rounded text-xs font-bold cursor-pointer transition ${
                  animMode === 'idle' ? 'bg-[#D9822B] text-black' : 'bg-white/5 text-[#E6ECE8] hover:bg-white/10'
                }`}
              >
                وقوف وتنفس
              </button>
              <button
                onClick={() => setAnimMode('walk')}
                className={`px-3 py-1.5 rounded text-xs font-bold cursor-pointer transition ${
                  animMode === 'walk' ? 'bg-[#D9822B] text-black' : 'bg-white/5 text-[#E6ECE8] hover:bg-white/10'
                }`}
              >
                مشي / ترصّد
              </button>
              <button
                onClick={() => setAnimMode('sprint')}
                className={`px-3 py-1.5 rounded text-xs font-bold cursor-pointer transition flex items-center gap-1 ${
                  animMode === 'sprint' ? 'bg-[#D9822B] text-black' : 'bg-white/5 text-[#E6ECE8] hover:bg-white/10'
                }`}
              >
                <Zap className="w-3.5 h-3.5" />
                {selected === 'survivor' ? 'ركض وشعاع عالي' : 'انقضاض ومطاردة'}
              </button>
              <button
                onClick={() => setAnimMode('stun')}
                className={`px-3 py-1.5 rounded text-xs font-bold cursor-pointer transition flex items-center gap-1 ${
                  animMode === 'stun' ? 'bg-[#C93B2B] text-white' : 'bg-white/5 text-[#E6ECE8] hover:bg-white/10'
                }`}
              >
                <Flame className="w-3.5 h-3.5" />
                {selected === 'survivor' ? 'تسلل وانحناء' : 'صعق بالضوء'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
