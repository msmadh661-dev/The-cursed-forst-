import React from 'react';
import {
  Activity,
  BatteryCharging,
  Camera,
  Compass,
  Eye,
  Flame,
  Flashlight,
  HeartPulse,
  Pause,
  Radio,
  ShieldPlus,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';
import { CompassMarker, PlayerStats } from '../game/types';

interface TacticalHUDProps {
  stats: PlayerStats;
  compassMarkers: CompassMarker[];
  isMuted: boolean;
  onToggleMute: () => void;
  onToggleCamera: () => void;
  onToggleFlashlight: () => void;
  onTriggerHighBeam: (active: boolean) => void;
  onThrowFlare: () => void;
  onUseMedkit: () => void;
  onToggleCrouch: () => void;
  onInteractHold: (holding: boolean) => void;
  onOpenInspector: () => void;
  onPause: () => void;
}

export const TacticalHUD: React.FC<TacticalHUDProps> = ({
  stats,
  compassMarkers,
  isMuted,
  onToggleMute,
  onToggleCamera,
  onToggleFlashlight,
  onTriggerHighBeam,
  onThrowFlare,
  onUseMedkit,
  onToggleCrouch,
  onInteractHold,
  onOpenInspector,
  onPause,
}) => {
  const cardinalDirections = [
    { deg: 0, label: 'شمال' },
    { deg: 45, label: 'ش.ش' },
    { deg: 90, label: 'شرق' },
    { deg: 135, label: 'ج.ش' },
    { deg: 180, label: 'جنوب' },
    { deg: 225, label: 'ج.غ' },
    { deg: 270, label: 'غرب' },
    { deg: 315, label: 'ش.غ' },
  ];

  const getRelativeAngle = (targetDeg: number) => {
    let diff = ((targetDeg - stats.headingDeg + 540) % 360) - 180;
    return diff;
  };

  return (
    <div className="fixed inset-0 pointer-events-none z-20 flex flex-col justify-between p-3 sm:p-5 select-none">
      {/* Danger Blood/Fear Vignette when monster is close or health is low */}
      {(stats.dangerLevel > 0.15 || stats.health < 40) && (
        <div
          className="fixed inset-0 pointer-events-none transition-opacity duration-300 danger-vignette-pulse"
          style={{
            background: `radial-gradient(circle, transparent 48%, rgba(201, 59, 43, ${Math.min(
              0.68,
              stats.dangerLevel * 0.65 + (stats.health < 40 ? 0.28 : 0)
            )}) 100%)`,
          }}
        />
      )}

      {/* TOP BAR: Compass Tape + Mission Objective + Utility Buttons */}
      <div className="flex items-start justify-between gap-3 w-full">
        {/* Right Corner (RTL): Mission Status */}
        <div className="tactical-panel rounded-lg px-3.5 py-2.5 max-w-xs pointer-events-auto">
          <div className="flex items-center gap-2 text-xs font-bold text-[#D9822B] mb-1">
            <Radio className="w-4 h-4 animate-pulse" />
            <span>المهمة الحالية للنجاة</span>
          </div>
          {!stats.extractionReady ? (
            <div>
              <div className="text-sm font-bold text-[#E6ECE8]">
                تفعيل أبراج الإشارة اللاسلكية ({stats.beaconsActivated} / {stats.totalBeacons})
              </div>
              <p className="text-[11px] text-[#8A9E93] mt-0.5">
                اتبع العلامات على البوصلة العلوية لتشغيل الأبراج وطلب الإخلاء.
              </p>
            </div>
          ) : (
            <div>
              <div className="text-sm font-bold text-[#38B566]">
                منطقة الإخلاء جاهزة! اتجه نحو الشمال فوراً
              </div>
              <div className="w-full bg-black/50 h-2 rounded-full mt-1.5 overflow-hidden border border-[#38B566]/40">
                <div
                  className="bg-[#38B566] h-full transition-all duration-150"
                  style={{ width: `${stats.extractionProgress}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Center Top: Horizontal Compass Tape */}
        <div className="flex flex-col items-center flex-1 max-w-md mx-auto">
          <div className="tactical-panel w-full h-11 rounded-lg relative overflow-hidden flex items-center justify-center px-4 border border-[#8A9E93]/25">
            {/* Center lubber line */}
            <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-0.5 bg-[#D9822B] z-10" />

            {/* Cardinal labels */}
            {cardinalDirections.map((dir) => {
              const rel = getRelativeAngle(dir.deg);
              if (Math.abs(rel) > 75) return null;
              const leftPct = 50 + (rel / 75) * 45;
              return (
                <div
                  key={dir.label}
                  className="absolute top-1.5 -translate-x-1/2 text-[11px] font-bold text-[#8A9E93]"
                  style={{ left: `${leftPct}%` }}
                >
                  {dir.label}
                </div>
              );
            })}

            {/* Landmarks, Beacons & Monster Threat Markers */}
            {compassMarkers.map((m) => {
              const rel = getRelativeAngle(m.angleDeg);
              const clampedRel = Math.max(-72, Math.min(72, rel));
              const leftPct = 50 + (clampedRel / 75) * 45;

              if (m.type === 'monster' && m.distance > 38) return null;

              return (
                <div
                  key={m.id}
                  className="absolute bottom-1 -translate-x-1/2 flex flex-col items-center"
                  style={{ left: `${leftPct}%` }}
                >
                  <div
                    className={`w-2.5 h-2.5 rounded-full ${
                      m.type === 'extraction'
                        ? 'bg-[#38B566] shadow-[0_0_8px_#38B566] animate-ping'
                        : m.type === 'beacon'
                          ? m.activated
                            ? 'bg-[#38B566]'
                            : 'bg-[#D9822B] shadow-[0_0_8px_#D9822B]'
                          : 'bg-[#C93B2B] shadow-[0_0_8px_#C93B2B]'
                    }`}
                  />
                  <span className="text-[9px] font-mono-tech text-[#E6ECE8]/80 leading-none mt-0.5">
                    {Math.round(m.distance)}م
                  </span>
                </div>
              );
            })}
          </div>

          {/* Radio Status Notification Banner */}
          {stats.statusMessageAr && (
            <div className="mt-2 tactical-panel-amber px-3.5 py-1.5 rounded-full text-xs font-medium text-[#E6ECE8] flex items-center gap-2 shadow-lg">
              <Compass className="w-3.5 h-3.5 text-[#D9822B] shrink-0" />
              <span>{stats.statusMessageAr}</span>
            </div>
          )}
        </div>

        {/* Left Corner (RTL): Camera Mode + 3D Character Studio + Sound + Pause */}
        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={onToggleCamera}
            className="tactical-panel px-3 py-2 rounded-lg text-xs font-bold text-[#E6ECE8] hover:border-[#D9822B] transition flex items-center gap-1.5 cursor-pointer"
            title="تبديل الكاميرا [V]"
          >
            <Camera className="w-4 h-4 text-[#D9822B]" />
            <span className="hidden sm:inline">
              {stats.cameraMode === 'third-person' ? 'منظور الشخص الثالث' : 'منظور الشخص الأول'}
            </span>
            <span className="font-mono-tech text-[10px] text-[#8A9E93]">[V]</span>
          </button>

          <button
            onClick={onOpenInspector}
            className="tactical-panel px-3 py-2 rounded-lg text-xs font-bold text-[#D9822B] hover:bg-[#D9822B]/15 transition flex items-center gap-1.5 cursor-pointer"
            title="فحص الشخصيات والوحوش 3D"
          >
            <Eye className="w-4 h-4" />
            <span className="hidden md:inline">فحص الشخصيات 3D</span>
          </button>

          <button
            onClick={onToggleMute}
            className="tactical-panel p-2 rounded-lg text-[#E6ECE8] hover:text-[#D9822B] transition cursor-pointer"
            title="كتم / تشغيل الصوت"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-[#C93B2B]" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            onClick={onPause}
            className="tactical-panel p-2 rounded-lg text-[#E6ECE8] hover:text-[#D9822B] transition cursor-pointer"
            title="إيقاف مؤقت [P]"
          >
            <Pause className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* CENTER RETICLE & CONTEXTUAL INTERACTION PROMPT */}
      <div className="flex flex-col items-center justify-center my-auto pointer-events-none">
        <div
          className={`rounded-full transition-all duration-150 flex items-center justify-center ${
            stats.highBeamActive
              ? 'w-11 h-11 border-2 border-[#D9822B] shadow-[0_0_20px_rgba(217,130,43,0.65)]'
              : 'w-5 h-5 border border-white/35'
          }`}
        >
          <div className="w-1 h-1 rounded-full bg-[#D9822B]" />
        </div>

        {stats.activePromptAr && (
          <div className="mt-6 pointer-events-auto">
            <button
              onMouseDown={() => onInteractHold(true)}
              onMouseUp={() => onInteractHold(false)}
              onTouchStart={() => onInteractHold(true)}
              onTouchEnd={() => onInteractHold(false)}
              className="tactical-panel-amber px-4 py-2 rounded-lg text-sm font-bold text-[#E6ECE8] flex items-center gap-2 animate-bounce cursor-pointer"
            >
              <span className="bg-[#D9822B] text-black font-mono-tech text-xs px-2 py-0.5 rounded font-extrabold">
                E
              </span>
              <span>{stats.activePromptAr}</span>
            </button>
          </div>
        )}
      </div>

      {/* BOTTOM BAR: Right = Vitals & Stealth | Left = Flashlight & Tactical Gear */}
      <div className="flex items-end justify-between gap-4 w-full">
        {/* Bottom Right (RTL): Survivor Vitals (Health, Stamina, Heartbeat, Stealth) */}
        <div className="tactical-panel rounded-xl p-3.5 w-64 sm:w-72 pointer-events-auto">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-[#E6ECE8] flex items-center gap-1.5">
              <HeartPulse
                className={`w-4 h-4 ${
                  stats.dangerLevel > 0.4 || stats.health < 35 ? 'text-[#C93B2B] animate-ping' : 'text-[#38B566]'
                }`}
              />
              المؤشرات الحيوية - آدم
            </span>
            <span className="font-mono-tech text-xs font-bold text-[#D9822B] flex items-center gap-1">
              <Activity className="w-3.5 h-3.5" />
              {Math.round(stats.heartbeatBpm)} BPM
            </span>
          </div>

          {/* Health Bar */}
          <div className="mb-2.5">
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-[#8A9E93]">الصحة البدنية</span>
              <span className="font-mono-tech font-bold text-[#E6ECE8]">{Math.ceil(stats.health)}%</span>
            </div>
            <div className="w-full h-2 bg-black/60 rounded-full overflow-hidden border border-white/10">
              <div
                className="h-full transition-all duration-200 rounded-full"
                style={{
                  width: `${Math.max(0, stats.health)}%`,
                  backgroundColor:
                    stats.health > 55 ? '#38B566' : stats.health > 28 ? '#F5B841' : '#C93B2B',
                }}
              />
            </div>
          </div>

          {/* Stamina Bar */}
          <div className="mb-3">
            <div className="flex justify-between text-[11px] mb-1">
              <span className="text-[#8A9E93]">طاقة التحمل والركض</span>
              <span className="font-mono-tech font-bold text-[#E6ECE8]">{Math.ceil(stats.stamina)}%</span>
            </div>
            <div className="w-full h-1.5 bg-black/60 rounded-full overflow-hidden border border-white/10">
              <div
                className="h-full bg-[#D9822B] transition-all duration-150 rounded-full"
                style={{ width: `${Math.max(0, stats.stamina)}%` }}
              />
            </div>
          </div>

          {/* Quick posture & Medkit row */}
          <div className="flex items-center justify-between gap-2 pt-2 border-t border-white/10">
            <button
              onClick={onToggleCrouch}
              className={`flex-1 py-1.5 px-2 rounded text-xs font-bold transition cursor-pointer border ${
                stats.isCrouching
                  ? 'bg-[#38B566]/20 border-[#38B566] text-[#38B566]'
                  : 'bg-white/5 border-white/10 text-[#8A9E93] hover:text-white'
              }`}
            >
              {stats.isCrouching ? 'وضع التسلل نشط [C]' : 'انحناء للتسلل [C]'}
            </button>

            <button
              onClick={onUseMedkit}
              disabled={stats.medkitsCount <= 0 || stats.health >= 100}
              className="py-1.5 px-2.5 rounded text-xs font-bold bg-[#38B566]/15 border border-[#38B566]/40 text-[#E6ECE8] hover:bg-[#38B566]/25 disabled:opacity-40 transition flex items-center gap-1 cursor-pointer"
              title="استخدام حقيبة إسعافات [H]"
            >
              <ShieldPlus className="w-3.5 h-3.5 text-[#38B566]" />
              <span className="font-mono-tech">{stats.medkitsCount}</span>
              <span className="text-[10px] text-[#8A9E93]">[H]</span>
            </button>
          </div>
        </div>

        {/* Bottom Left (RTL): Flashlight Battery, High-Beam Burn & Flares */}
        <div className="tactical-panel rounded-xl p-3.5 w-64 sm:w-80 pointer-events-auto">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-[#E6ECE8] flex items-center gap-1.5">
              <Flashlight className={`w-4 h-4 ${stats.flashlightOn ? 'text-[#D9822B]' : 'text-[#8A9E93]'}`} />
              الكشاف التكتيكي والمعدات
            </span>
            <span className="font-mono-tech text-xs font-bold text-[#D9822B] flex items-center gap-1">
              <BatteryCharging className="w-3.5 h-3.5" />
              {Math.ceil(stats.battery)}%
            </span>
          </div>

          {/* Battery Bar */}
          <div className="w-full h-2 bg-black/60 rounded-full overflow-hidden border border-white/10 mb-3">
            <div
              className="h-full transition-all duration-150 rounded-full"
              style={{
                width: `${Math.max(0, stats.battery)}%`,
                backgroundColor: stats.battery > 30 ? '#3b82f6' : '#C93B2B',
              }}
            />
          </div>

          {/* Action Buttons for Flashlight, High-Beam Burn, and Flares */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={onToggleFlashlight}
              className={`py-2 px-2 rounded-lg text-xs font-bold border transition flex flex-col items-center gap-1 cursor-pointer ${
                stats.flashlightOn
                  ? 'bg-[#D9822B]/20 border-[#D9822B] text-[#E6ECE8]'
                  : 'bg-white/5 border-white/10 text-[#8A9E93]'
              }`}
            >
              <Flashlight className="w-4 h-4" />
              <span>الكشاف [F]</span>
            </button>

            <button
              onMouseDown={() => onTriggerHighBeam(true)}
              onMouseUp={() => onTriggerHighBeam(false)}
              onMouseLeave={() => onTriggerHighBeam(false)}
              onTouchStart={() => onTriggerHighBeam(true)}
              onTouchEnd={() => onTriggerHighBeam(false)}
              className={`py-2 px-2 rounded-lg text-xs font-bold border transition flex flex-col items-center gap-1 cursor-pointer ${
                stats.highBeamActive
                  ? 'bg-[#F5B841] border-white text-black shadow-[0_0_15px_#F5B841]'
                  : 'bg-white/5 border-white/10 text-[#E6ECE8] hover:border-[#F5B841]/50'
              }`}
              title="اضغط مطولاً على المسافة أو الزر الأيمن لحرق وصعق الوحوش بالضوء العالي"
            >
              <Zap className="w-4 h-4 text-[#F5B841]" />
              <span>شعاع حارق</span>
            </button>

            <button
              onClick={onThrowFlare}
              disabled={stats.flaresCount <= 0}
              className="py-2 px-2 rounded-lg text-xs font-bold bg-[#C93B2B]/20 border border-[#C93B2B]/50 text-[#E6ECE8] hover:bg-[#C93B2B]/35 disabled:opacity-40 transition flex flex-col items-center gap-1 cursor-pointer"
              title="إلقاء مشعل حراري لطرد الوحوش [G]"
            >
              <div className="flex items-center gap-1">
                <Flame className="w-4 h-4 text-[#f87171]" />
                <span className="font-mono-tech">{stats.flaresCount}</span>
              </div>
              <span>مشعل [G]</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
