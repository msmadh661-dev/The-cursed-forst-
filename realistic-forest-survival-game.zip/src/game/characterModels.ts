import * as THREE from 'three';
import {
  createBoneSkullTexture,
  createFabricTexture,
  createHumanSkinTexture,
  createMonsterHideTextures,
} from './proceduralTextures';
import { MonsterArchetype, MonsterEntity } from './types';

export interface SurvivorRig {
  root: THREE.Group;
  pelvis: THREE.Group;
  torso: THREE.Group;
  headGroup: THREE.Group;
  leftShoulder: THREE.Group;
  leftForearm: THREE.Group;
  rightShoulder: THREE.Group;
  rightForearm: THREE.Group;
  leftHip: THREE.Group;
  leftCalf: THREE.Group;
  rightHip: THREE.Group;
  rightCalf: THREE.Group;
  flashlightSpot: THREE.SpotLight;
  flashlightTarget: THREE.Object3D;
  flashlightConeMesh: THREE.Mesh;
  flashlightLensMat: THREE.MeshStandardMaterial;
}

export function buildSurvivorCharacter(): SurvivorRig {
  const root = new THREE.Group();

  const skinTex = createHumanSkinTexture();
  const jacketTex = createFabricTexture('#2f3d32', true);
  const pantsTex = createFabricTexture('#26282a', true);
  const leatherTex = createFabricTexture('#2b1d14', true);
  const packTex = createFabricTexture('#3b3528', true);

  const skinMat = new THREE.MeshStandardMaterial({
    map: skinTex,
    roughness: 0.58,
    metalness: 0.04,
  });

  const jacketMat = new THREE.MeshStandardMaterial({
    map: jacketTex,
    roughness: 0.82,
    metalness: 0.05,
  });

  const pantsMat = new THREE.MeshStandardMaterial({
    map: pantsTex,
    roughness: 0.85,
    metalness: 0.04,
  });

  const bootMat = new THREE.MeshStandardMaterial({
    map: leatherTex,
    roughness: 0.65,
    metalness: 0.12,
  });

  const hairMat = new THREE.MeshStandardMaterial({
    color: 0x1a1614,
    roughness: 0.88,
  });

  const packMat = new THREE.MeshStandardMaterial({
    map: packTex,
    roughness: 0.78,
  });

  // PELVIS (height ~ 0.94m from ground)
  const pelvis = new THREE.Group();
  pelvis.position.set(0, 0.94, 0);
  root.add(pelvis);

  const hipsMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.165, 0.155, 0.2, 16), pantsMat);
  hipsMesh.scale.set(1.15, 1, 0.82);
  hipsMesh.castShadow = true;
  hipsMesh.receiveShadow = true;
  pelvis.add(hipsMesh);

  // Tactical leather belt & metallic buckle
  const beltMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.172, 0.172, 0.055, 16), bootMat);
  beltMesh.scale.set(1.15, 1, 0.84);
  beltMesh.position.y = 0.07;
  pelvis.add(beltMesh);

  // TORSO
  const torso = new THREE.Group();
  torso.position.set(0, 0.1, 0);
  pelvis.add(torso);

  // Lower abdomen & chest (sculpted field parka)
  const abdomenMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.195, 0.17, 0.28, 18), jacketMat);
  abdomenMesh.scale.set(1.18, 1, 0.8);
  abdomenMesh.position.y = 0.14;
  abdomenMesh.castShadow = true;
  torso.add(abdomenMesh);

  const chestMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.195, 0.32, 18), jacketMat);
  chestMesh.scale.set(1.22, 1, 0.84);
  chestMesh.position.y = 0.4;
  chestMesh.castShadow = true;
  torso.add(chestMesh);

  // High storm collar around neck
  const collarMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.13, 0.1, 16, 1, true), jacketMat);
  collarMesh.position.set(0, 0.57, 0);
  torso.add(collarMesh);

  // Survival Backpack with sleeping roll & radio antenna
  const backpackGroup = new THREE.Group();
  backpackGroup.position.set(0, 0.34, 0.21);
  torso.add(backpackGroup);

  const mainPack = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.42, 0.17), packMat);
  mainPack.castShadow = true;
  backpackGroup.add(mainPack);

  const bedroll = new THREE.Mesh(
    new THREE.CylinderGeometry(0.065, 0.065, 0.34, 14),
    new THREE.MeshStandardMaterial({ color: 0x4b2e22, roughness: 0.85 })
  );
  bedroll.rotation.z = Math.PI / 2;
  bedroll.position.set(0, 0.24, 0);
  backpackGroup.add(bedroll);

  // Radio whip antenna on backpack + blinking green survival transponder LED
  const antenna = new THREE.Mesh(
    new THREE.CylinderGeometry(0.004, 0.007, 0.48, 6),
    new THREE.MeshStandardMaterial({ color: 0x77807a, metalness: 0.8, roughness: 0.3 })
  );
  antenna.position.set(0.12, 0.38, 0);
  backpackGroup.add(antenna);

  const transponderLed = new THREE.Mesh(
    new THREE.SphereGeometry(0.015, 8, 8),
    new THREE.MeshStandardMaterial({
      color: 0x38b566,
      emissive: 0x22a552,
      emissiveIntensity: 1.8,
    })
  );
  transponderLed.position.set(-0.11, 0.15, 0.09);
  backpackGroup.add(transponderLed);

  // HEAD & NECK (Anatomical proportions)
  const headGroup = new THREE.Group();
  headGroup.position.set(0, 0.58, 0);
  torso.add(headGroup);

  const neckMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.062, 0.072, 0.11, 14), skinMat);
  neckMesh.position.y = 0.04;
  headGroup.add(neckMesh);

  // Cranium + Jawline
  const cranium = new THREE.Mesh(new THREE.SphereGeometry(0.112, 22, 20), skinMat);
  cranium.scale.set(0.92, 1.08, 0.98);
  cranium.position.set(0, 0.16, -0.01);
  cranium.castShadow = true;
  headGroup.add(cranium);

  // Sculpted Nose
  const nose = new THREE.Mesh(new THREE.ConeGeometry(0.02, 0.055, 8), skinMat);
  nose.rotation.x = -Math.PI * 0.42;
  nose.position.set(0, 0.155, -0.115);
  headGroup.add(nose);

  // Brow ridge
  const brow = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.022, 0.04), skinMat);
  brow.position.set(0, 0.19, -0.095);
  headGroup.add(brow);

  // Realistic Eyes
  const scleraMat = new THREE.MeshStandardMaterial({ color: 0xedeae4, roughness: 0.25 });
  const irisMat = new THREE.MeshStandardMaterial({ color: 0x23170f, roughness: 0.15 });
  [-0.036, 0.036].forEach((xOffset) => {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.014, 10, 10), scleraMat);
    eye.position.set(xOffset, 0.172, -0.098);
    headGroup.add(eye);

    const iris = new THREE.Mesh(new THREE.SphereGeometry(0.008, 8, 8), irisMat);
    iris.position.set(xOffset, 0.172, -0.109);
    headGroup.add(iris);
  });

  // Ears
  [-0.102, 0.102].forEach((xOffset) => {
    const ear = new THREE.Mesh(new THREE.SphereGeometry(0.024, 8, 8), skinMat);
    ear.scale.set(0.45, 1.1, 0.7);
    ear.position.set(xOffset, 0.155, -0.005);
    headGroup.add(ear);
  });

  // Hair & Weathered Beard
  const hairCap = new THREE.Mesh(new THREE.SphereGeometry(0.117, 18, 16), hairMat);
  hairCap.scale.set(0.95, 0.95, 1.02);
  hairCap.position.set(0, 0.19, 0.005);
  headGroup.add(hairCap);

  const beard = new THREE.Mesh(new THREE.SphereGeometry(0.098, 16, 14), hairMat);
  beard.scale.set(0.92, 0.78, 0.95);
  beard.position.set(0, 0.105, -0.022);
  headGroup.add(beard);

  // ARMS
  const createArm = (isRight: boolean) => {
    const shoulder = new THREE.Group();
    shoulder.position.set(isRight ? 0.265 : -0.265, 0.5, 0);
    torso.add(shoulder);

    const upperArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.056, 0.22, 8, 14), jacketMat);
    upperArm.position.y = -0.13;
    upperArm.castShadow = true;
    shoulder.add(upperArm);

    const forearm = new THREE.Group();
    forearm.position.set(0, -0.27, 0);
    shoulder.add(forearm);

    const lowerArmMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.046, 0.21, 8, 14), jacketMat);
    lowerArmMesh.position.y = -0.12;
    lowerArmMesh.castShadow = true;
    forearm.add(lowerArmMesh);

    // Fingerless tactical glove + hand
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.044, 12, 12), skinMat);
    hand.scale.set(0.85, 1.15, 0.65);
    hand.position.set(0, -0.25, 0);
    forearm.add(hand);

    return { shoulder, forearm };
  };

  const leftArm = createArm(false);
  const rightArm = createArm(true);

  // Equip Emergency Flare on Left Hand
  const flareStick = new THREE.Mesh(
    new THREE.CylinderGeometry(0.016, 0.016, 0.18, 10),
    new THREE.MeshStandardMaterial({ color: 0xb92e2b, roughness: 0.5 })
  );
  flareStick.rotation.x = Math.PI / 2;
  flareStick.position.set(0, -0.26, -0.04);
  leftArm.forearm.add(flareStick);

  // Equip Heavy-Duty Tactical Flashlight in Right Hand
  const flashlightGroup = new THREE.Group();
  flashlightGroup.position.set(0, -0.25, -0.06);
  rightArm.forearm.add(flashlightGroup);

  const flashBody = new THREE.Mesh(
    new THREE.CylinderGeometry(0.024, 0.02, 0.22, 14),
    new THREE.MeshStandardMaterial({ color: 0x1c2022, metalness: 0.85, roughness: 0.28 })
  );
  flashBody.rotation.x = Math.PI / 2;
  flashlightGroup.add(flashBody);

  const flashBezel = new THREE.Mesh(
    new THREE.CylinderGeometry(0.034, 0.024, 0.06, 16),
    new THREE.MeshStandardMaterial({ color: 0x2b3033, metalness: 0.9, roughness: 0.2 })
  );
  flashBezel.rotation.x = Math.PI / 2;
  flashBezel.position.z = -0.12;
  flashlightGroup.add(flashBezel);

  const flashlightLensMat = new THREE.MeshStandardMaterial({
    color: 0xfff3d6,
    emissive: 0xffd89b,
    emissiveIntensity: 3.5,
    roughness: 0.1,
  });
  const lensMesh = new THREE.Mesh(new THREE.CircleGeometry(0.031, 16), flashlightLensMat);
  lensMesh.rotation.y = Math.PI;
  lensMesh.position.z = -0.151;
  flashlightGroup.add(lensMesh);

  // Volumetric-feeling beam cone attached to flashlight
  const coneGeo = new THREE.ConeGeometry(1.65, 11.5, 24, 1, true);
  coneGeo.translate(0, -5.75, 0);
  coneGeo.rotateX(-Math.PI / 2);
  const coneMat = new THREE.MeshBasicMaterial({
    color: 0xffebc4,
    transparent: true,
    opacity: 0.065,
    side: THREE.DoubleSide,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const flashlightConeMesh = new THREE.Mesh(coneGeo, coneMat);
  flashlightConeMesh.position.z = -0.15;
  flashlightGroup.add(flashlightConeMesh);

  // Real Three.js SpotLight for the flashlight
  const flashlightSpot = new THREE.SpotLight(0xffe9c2, 5.5, 46, Math.PI * 0.22, 0.55, 1.35);
  flashlightSpot.position.set(0, 0, -0.16);
  flashlightSpot.castShadow = true;
  flashlightSpot.shadow.mapSize.width = 1024;
  flashlightSpot.shadow.mapSize.height = 1024;
  flashlightSpot.shadow.camera.near = 0.4;
  flashlightSpot.shadow.camera.far = 46;
  flashlightSpot.shadow.bias = -0.0008;
  flashlightGroup.add(flashlightSpot);

  const flashlightTarget = new THREE.Object3D();
  flashlightTarget.position.set(0, 0, -15);
  flashlightGroup.add(flashlightTarget);
  flashlightSpot.target = flashlightTarget;

  // LEGS & MUD-STAINED BOOTS
  const createLeg = (isRight: boolean) => {
    const hip = new THREE.Group();
    hip.position.set(isRight ? 0.105 : -0.105, -0.05, 0);
    pelvis.add(hip);

    const thigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.074, 0.34, 8, 14), pantsMat);
    thigh.position.y = -0.21;
    thigh.castShadow = true;
    hip.add(thigh);

    const calf = new THREE.Group();
    calf.position.set(0, -0.43, 0);
    hip.add(calf);

    const shin = new THREE.Mesh(new THREE.CapsuleGeometry(0.058, 0.33, 8, 14), pantsMat);
    shin.position.y = -0.19;
    shin.castShadow = true;
    calf.add(shin);

    // Heavy hiking boot
    const boot = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.11, 0.24), bootMat);
    boot.position.set(0, -0.41, -0.035);
    boot.castShadow = true;
    calf.add(boot);

    return { hip, calf };
  };

  const leftLeg = createLeg(false);
  const rightLeg = createLeg(true);

  return {
    root,
    pelvis,
    torso,
    headGroup,
    leftShoulder: leftArm.shoulder,
    leftForearm: leftArm.forearm,
    rightShoulder: rightArm.shoulder,
    rightForearm: rightArm.forearm,
    leftHip: leftLeg.hip,
    leftCalf: leftLeg.calf,
    rightHip: rightLeg.hip,
    rightCalf: rightLeg.calf,
    flashlightSpot,
    flashlightTarget,
    flashlightConeMesh,
    flashlightLensMat,
  };
}

export function animateSurvivor(
  rig: SurvivorRig,
  time: number,
  moveSpeed: number,
  isSprinting: boolean,
  isCrouching: boolean,
  aimPitch: number,
  highBeamActive: boolean
) {
  const isMoving = moveSpeed > 0.15;
  const freq = isSprinting ? 11.5 : isCrouching ? 5.5 : 7.8;
  const strideAmp = isSprinting ? 0.68 : isCrouching ? 0.32 : 0.46;

  // Pelvis height & bob
  const basePelvisY = isCrouching ? 0.68 : 0.94;
  const bob = isMoving ? Math.abs(Math.sin(time * freq)) * (isSprinting ? 0.055 : 0.032) : Math.sin(time * 2.1) * 0.008;
  rig.pelvis.position.y = THREE.MathUtils.lerp(rig.pelvis.position.y, basePelvisY + bob, 0.2);

  // Forward torso lean
  const targetLean = isCrouching ? -0.35 : isSprinting && isMoving ? -0.22 : -0.05;
  rig.torso.rotation.x = THREE.MathUtils.lerp(rig.torso.rotation.x, targetLean, 0.15);
  rig.torso.rotation.y = isMoving ? Math.sin(time * freq) * 0.06 : 0;

  // Head pitch & subtle scan
  rig.headGroup.rotation.x = THREE.MathUtils.clamp(aimPitch * 0.55 - targetLean * 0.6, -0.5, 0.5);

  if (isMoving) {
    const phase = time * freq;
    const leftSwing = Math.sin(phase) * strideAmp;
    const rightSwing = Math.sin(phase + Math.PI) * strideAmp;

    rig.leftHip.rotation.x = leftSwing;
    rig.rightHip.rotation.x = rightSwing;

    rig.leftCalf.rotation.x = -Math.max(0, Math.cos(phase) * strideAmp * 1.15) - (isCrouching ? 0.35 : 0.08);
    rig.rightCalf.rotation.x = -Math.max(0, Math.cos(phase + Math.PI) * strideAmp * 1.15) - (isCrouching ? 0.35 : 0.08);

    // Left arm counter-swings naturally
    rig.leftShoulder.rotation.x = rightSwing * 0.65;
    rig.leftForearm.rotation.x = 0.45 + Math.max(0, rightSwing * 0.3);
  } else {
    rig.leftHip.rotation.x = THREE.MathUtils.lerp(rig.leftHip.rotation.x, isCrouching ? 0.42 : 0, 0.15);
    rig.rightHip.rotation.x = THREE.MathUtils.lerp(rig.rightHip.rotation.x, isCrouching ? 0.42 : 0, 0.15);
    rig.leftCalf.rotation.x = THREE.MathUtils.lerp(rig.leftCalf.rotation.x, isCrouching ? -0.75 : -0.05, 0.15);
    rig.rightCalf.rotation.x = THREE.MathUtils.lerp(rig.rightCalf.rotation.x, isCrouching ? -0.75 : -0.05, 0.15);
    rig.leftShoulder.rotation.x = THREE.MathUtils.lerp(rig.leftShoulder.rotation.x, 0.1, 0.15);
    rig.leftForearm.rotation.x = THREE.MathUtils.lerp(rig.leftForearm.rotation.x, 0.55, 0.15);
  }

  // Right arm holds the tactical flashlight steady forward, raised higher when High-Beam is focused
  const targetRightShoulderX = (highBeamActive ? 0.92 : 0.62) + aimPitch * 0.7;
  const targetRightForearmX = highBeamActive ? 0.48 : 0.65;
  rig.rightShoulder.rotation.x = THREE.MathUtils.lerp(rig.rightShoulder.rotation.x, targetRightShoulderX, 0.22);
  rig.rightShoulder.rotation.z = THREE.MathUtils.lerp(rig.rightShoulder.rotation.z, highBeamActive ? -0.08 : 0.05, 0.2);
  rig.rightForearm.rotation.x = THREE.MathUtils.lerp(rig.rightForearm.rotation.x, targetRightForearmX, 0.22);
}

// ============================================================================
// REALISTIC-LEANING FOREST MONSTER BUILDER (3 Distinct Horror Archetypes)
// ============================================================================
export function buildMonsterCharacter(
  id: string,
  archetype: MonsterArchetype,
  spawnPos: THREE.Vector3
): MonsterEntity {
  const meshGroup = new THREE.Group();
  meshGroup.position.copy(spawnPos);

  const { map: hideMap, bumpMap: hideBump } = createMonsterHideTextures(archetype);
  const boneTex = createBoneSkullTexture();

  const hideMat = new THREE.MeshStandardMaterial({
    map: hideMap,
    bumpMap: hideBump,
    bumpScale: 0.045,
    roughness: archetype === 'wendigo' ? 0.55 : 0.34, // wet organic sheen
    metalness: 0.08,
  });

  const boneMat = new THREE.MeshStandardMaterial({
    map: boneTex,
    roughness: 0.48,
    metalness: 0.05,
  });

  const clawMat = new THREE.MeshStandardMaterial({
    color: 0x15110e,
    roughness: 0.25,
    metalness: 0.3,
  });

  const eyeColor = archetype === 'wendigo' ? 0xff4518 : archetype === 'stalker' ? 0xff9b26 : 0x62f5b5;
  const eyesMaterial = new THREE.MeshStandardMaterial({
    color: eyeColor,
    emissive: eyeColor,
    emissiveIntensity: 3.4,
    roughness: 0.1,
  });

  const scaleMultiplier = archetype === 'wendigo' ? 1.34 : archetype === 'stalker' ? 1.12 : 0.92;
  meshGroup.scale.setScalar(scaleMultiplier);

  // PELVIS
  const pelvis = new THREE.Group();
  pelvis.position.set(0, 1.08, 0);
  meshGroup.add(pelvis);

  const pelvisMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.14, 0.18, 8, 14), hideMat);
  pelvisMesh.rotation.z = Math.PI / 2;
  pelvisMesh.castShadow = true;
  pelvis.add(pelvisMesh);

  // TORSO & EXPOSED RIBCAGE / SPINE
  const torso = new THREE.Group();
  torso.position.set(0, 0.1, 0);
  pelvis.add(torso);

  const spineColumn = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.11, 0.65, 14), hideMat);
  spineColumn.position.set(0, 0.3, 0);
  spineColumn.rotation.x = -0.18;
  spineColumn.castShadow = true;
  torso.add(spineColumn);

  const upperRibcage = new THREE.Mesh(new THREE.SphereGeometry(0.24, 16, 14), hideMat);
  upperRibcage.scale.set(1.18, 1.15, 0.85);
  upperRibcage.position.set(0, 0.46, -0.05);
  upperRibcage.castShadow = true;
  torso.add(upperRibcage);

  // Sculpted anatomical ribs & dorsal vertebrae spikes
  for (let i = 0; i < 5; i++) {
    const ribArc = new THREE.Mesh(
      new THREE.TorusGeometry(0.17 + i * 0.012, 0.016, 6, 14, Math.PI * 1.35),
      boneMat
    );
    ribArc.rotation.x = Math.PI / 2 + 0.2;
    ribArc.rotation.z = -Math.PI * 0.18;
    ribArc.position.set(0, 0.2 + i * 0.075, -0.04);
    torso.add(ribArc);

    // Dorsal vertebrae ridge along spine
    const vertebra = new THREE.Mesh(new THREE.ConeGeometry(0.025, 0.09, 6), boneMat);
    vertebra.rotation.x = Math.PI * 0.38;
    vertebra.position.set(0, 0.16 + i * 0.095, 0.14 - i * 0.012);
    torso.add(vertebra);
  }

  // NECK & HEAD
  const neck = new THREE.Group();
  neck.position.set(0, 0.66, -0.1);
  torso.add(neck);

  const neckMuscle = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.095, 0.22, 12), hideMat);
  neckMuscle.rotation.x = -0.35;
  neckMuscle.position.y = 0.08;
  neck.add(neckMuscle);

  const head = new THREE.Group();
  head.position.set(0, 0.18, -0.08);
  neck.add(head);

  // Cranium (bone skull for Wendigo, gaunt elongated skull for Stalker/Creeper)
  const skullMatToUse = archetype === 'wendigo' ? boneMat : hideMat;
  const cranium = new THREE.Mesh(new THREE.SphereGeometry(0.135, 16, 14), skullMatToUse);
  cranium.scale.set(0.88, 1.05, 1.38);
  cranium.position.set(0, 0.06, -0.06);
  cranium.castShadow = true;
  head.add(cranium);

  // Snout / Upper Jaw
  const snout = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.085, 0.22, 10), skullMatToUse);
  snout.rotation.x = Math.PI / 2;
  snout.position.set(0, 0.02, -0.2);
  head.add(snout);

  // Articulated Lower Jaw with Jagged Fangs
  const jaw = new THREE.Group();
  jaw.position.set(0, -0.03, -0.08);
  head.add(jaw);

  const lowerMandible = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.035, 0.2), skullMatToUse);
  lowerMandible.position.set(0, -0.02, -0.08);
  jaw.add(lowerMandible);

  // Fangs
  for (let f = -2; f <= 2; f++) {
    if (f === 0) continue;
    const fang = new THREE.Mesh(new THREE.ConeGeometry(0.009, 0.04, 5), boneMat);
    fang.position.set(f * 0.018, 0.01, -0.15);
    jaw.add(fang);
  }

  // Deep-set Glowing Predator Eyes
  [-0.048, 0.048].forEach((xOff) => {
    const eyeSocket = new THREE.Mesh(
      new THREE.SphereGeometry(0.024, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0x050505 })
    );
    eyeSocket.position.set(xOff, 0.075, -0.175);
    head.add(eyeSocket);

    const glowingIris = new THREE.Mesh(new THREE.SphereGeometry(0.015, 8, 8), eyesMaterial);
    glowingIris.position.set(xOff, 0.075, -0.19);
    head.add(glowingIris);
  });

  // Wendigo Branched Stag Antlers (makes the Elder Beast unforgettable & terrifying)
  if (archetype === 'wendigo') {
    [-1, 1].forEach((side) => {
      const antlerRoot = new THREE.Group();
      antlerRoot.position.set(side * 0.08, 0.15, -0.04);
      antlerRoot.rotation.z = side * -0.42;
      antlerRoot.rotation.x = -0.25;
      head.add(antlerRoot);

      const mainBeam = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.028, 0.58, 8), boneMat);
      mainBeam.position.y = 0.28;
      mainBeam.castShadow = true;
      antlerRoot.add(mainBeam);

      for (let t = 0; t < 3; t++) {
        const tine = new THREE.Mesh(new THREE.ConeGeometry(0.014, 0.26, 7), boneMat);
        tine.position.set(side * 0.06, 0.18 + t * 0.14, -0.06);
        tine.rotation.z = side * -0.55;
        tine.rotation.x = -0.45;
        antlerRoot.add(tine);
      }
    });
  }

  // ELONGATED PREDATOR ARMS & RAZOR CLAWS
  const createMonsterArm = (isRight: boolean) => {
    const shoulder = new THREE.Group();
    shoulder.position.set(isRight ? 0.28 : -0.28, 0.52, -0.04);
    torso.add(shoulder);

    const upperArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.055, 0.34, 8, 12), hideMat);
    upperArm.position.y = -0.18;
    upperArm.castShadow = true;
    shoulder.add(upperArm);

    const forearm = new THREE.Group();
    forearm.position.set(0, -0.38, 0);
    shoulder.add(forearm);

    const lowerArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.044, 0.38, 8, 12), hideMat);
    lowerArm.position.y = -0.2;
    lowerArm.castShadow = true;
    forearm.add(lowerArm);

    // 4 Long Curved Talons/Claws
    for (let c = -1.5; c <= 1.5; c += 1) {
      const claw = new THREE.Mesh(new THREE.ConeGeometry(0.01, 0.14, 6), clawMat);
      claw.rotation.x = Math.PI + 0.25;
      claw.position.set(c * 0.018, -0.44, -0.02);
      forearm.add(claw);
    }

    return { shoulder, forearm };
  };

  const leftArm = createMonsterArm(false);
  const rightArm = createMonsterArm(true);

  // DIGITIGRADE PREDATORY LEGS
  const createMonsterLeg = (isRight: boolean) => {
    const hip = new THREE.Group();
    hip.position.set(isRight ? 0.14 : -0.14, -0.04, 0);
    pelvis.add(hip);

    const thigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.075, 0.38, 8, 12), hideMat);
    thigh.position.y = -0.21;
    thigh.castShadow = true;
    hip.add(thigh);

    const calf = new THREE.Group();
    calf.position.set(0, -0.44, 0);
    hip.add(calf);

    const lowerLeg = new THREE.Mesh(new THREE.CapsuleGeometry(0.052, 0.44, 8, 12), hideMat);
    lowerLeg.position.y = -0.23;
    lowerLeg.castShadow = true;
    calf.add(lowerLeg);

    return { hip, calf };
  };

  const leftLeg = createMonsterLeg(false);
  const rightLeg = createMonsterLeg(true);

  const nameAr =
    archetype === 'wendigo'
      ? 'حارس القرون (الوينديغو)'
      : archetype === 'stalker'
        ? 'المترصد الليلي'
        : 'عدّاء الضباب';

  return {
    id,
    nameAr,
    archetype,
    meshGroup,
    joints: {
      pelvis,
      torso,
      neck,
      head,
      jaw,
      leftShoulder: leftArm.shoulder,
      leftForearm: leftArm.forearm,
      rightShoulder: rightArm.shoulder,
      rightForearm: rightArm.forearm,
      leftHip: leftLeg.hip,
      leftCalf: leftLeg.calf,
      rightHip: rightLeg.hip,
      rightCalf: rightLeg.calf,
      eyesMaterial,
    },
    position: spawnPos.clone(),
    velocity: new THREE.Vector3(),
    rotationY: Math.random() * Math.PI * 2,
    state: 'patrol',
    health: archetype === 'wendigo' ? 160 : archetype === 'stalker' ? 100 : 75,
    maxHealth: archetype === 'wendigo' ? 160 : archetype === 'stalker' ? 100 : 75,
    speedPatrol: archetype === 'creeper' ? 3.2 : 2.1,
    speedChase: archetype === 'creeper' ? 6.8 : archetype === 'stalker' ? 5.9 : 5.2,
    detectionRadius: archetype === 'wendigo' ? 34 : 28,
    attackDamage: archetype === 'wendigo' ? 34 : archetype === 'stalker' ? 22 : 16,
    attackCooldown: 0,
    stunTimer: 0,
    burnExposure: 0,
    patrolTarget: spawnPos.clone(),
    animPhase: Math.random() * 10,
    lastGrowlTime: 0,
  };
}

export function animateMonster(monster: MonsterEntity, dt: number, isMoving: boolean) {
  const isChasing = monster.state === 'chase';
  const isStunned = monster.state === 'stunned';
  const speedFreq = isChasing ? 11.5 : 5.6;
  monster.animPhase += dt * (isMoving ? speedFreq : 2.2);
  const p = monster.animPhase;

  const { joints } = monster;

  if (isStunned) {
    // Recoiling in pain from high-beam light or flare!
    joints.torso.rotation.x = THREE.MathUtils.lerp(joints.torso.rotation.x, 0.25, 0.2);
    joints.head.rotation.y = Math.sin(p * 6) * 0.45;
    joints.leftShoulder.rotation.x = 1.65;
    joints.rightShoulder.rotation.x = 1.55;
    joints.leftForearm.rotation.x = 1.1;
    joints.rightForearm.rotation.x = 1.1;
    if (joints.jaw) joints.jaw.rotation.x = -0.55;
    return;
  }

  // Predatory hunched posture
  const hunch = monster.archetype === 'creeper' ? -0.62 : isChasing ? -0.45 : -0.28;
  joints.torso.rotation.x = THREE.MathUtils.lerp(joints.torso.rotation.x, hunch + Math.sin(p) * 0.05, 0.15);
  joints.torso.rotation.z = Math.cos(p * 0.5) * 0.06;

  // Jaw breathing / snapping when chasing
  if (joints.jaw) {
    joints.jaw.rotation.x = isChasing ? -0.25 - Math.abs(Math.sin(p * 1.5)) * 0.35 : -0.08;
  }

  if (isMoving) {
    const legAmp = isChasing ? 0.78 : 0.45;
    const leftLegSwing = Math.sin(p) * legAmp;
    const rightLegSwing = Math.sin(p + Math.PI) * legAmp;

    joints.leftHip.rotation.x = leftLegSwing + 0.22;
    joints.rightHip.rotation.x = rightLegSwing + 0.22;

    joints.leftCalf.rotation.x = -0.45 - Math.max(0, Math.cos(p) * legAmp);
    joints.rightCalf.rotation.x = -0.45 - Math.max(0, Math.cos(p + Math.PI) * legAmp);

    // Arms reach forward menacingly during chase
    const armBase = isChasing ? 0.95 : 0.35;
    joints.leftShoulder.rotation.x = armBase + rightLegSwing * 0.65;
    joints.rightShoulder.rotation.x = armBase + leftLegSwing * 0.65;
    joints.leftForearm.rotation.x = 0.55 + Math.sin(p) * 0.25;
    joints.rightForearm.rotation.x = 0.55 + Math.cos(p) * 0.25;

    joints.pelvis.position.y = 1.04 + Math.abs(Math.sin(p)) * (isChasing ? 0.11 : 0.04);
  } else {
    joints.leftHip.rotation.x = 0.25;
    joints.rightHip.rotation.x = 0.25;
    joints.leftCalf.rotation.x = -0.5;
    joints.rightCalf.rotation.x = -0.5;
    joints.leftShoulder.rotation.x = 0.25 + Math.sin(p) * 0.06;
    joints.rightShoulder.rotation.x = 0.25 + Math.cos(p) * 0.06;
  }
}
