// Procedural Web Audio API Horror & Survival Sound Engine

class HorrorSoundEngine {
  private ctx: AudioContext | null = null;
  private windGain: GainNode | null = null;
  private muted = false;
  private lastFootstepTime = 0;
  private lastHeartbeatTime = 0;

  private ensureContext(): AudioContext | null {
    if (this.muted) return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public setMuted(mute: boolean) {
    this.muted = mute;
    if (this.windGain && this.ctx) {
      this.windGain.gain.setTargetAtTime(mute ? 0 : 0.045, this.ctx.currentTime, 0.2);
    }
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public startAmbientWind() {
    const ctx = this.ensureContext();
    if (!ctx || this.windGain) return;

    // Create pink-ish noise buffer for nocturnal forest wind
    const bufferSize = ctx.sampleRate * 4;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.04;
      b6 = white * 0.115926;
    }

    const noise = ctx.createBufferSource();
    noise.buffer = buffer;
    noise.loop = true;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 340;
    filter.Q.value = 1.8;

    // LFO to modulate wind gusts
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.14;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 160;
    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);
    lfo.start();

    this.windGain = ctx.createGain();
    this.windGain.gain.value = this.muted ? 0 : 0.05;

    noise.connect(filter);
    filter.connect(this.windGain);
    this.windGain.connect(ctx.destination);
    noise.start();
  }

  public playFootstep(isSprinting: boolean, isCrouching: boolean) {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = performance.now();
    const interval = isSprinting ? 290 : isCrouching ? 620 : 450;
    if (now - this.lastFootstepTime < interval) return;
    this.lastFootstepTime = now;

    const t = ctx.currentTime;
    // Short crunch of leaves/soil
    const dur = 0.085;
    const buf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * dur), ctx.sampleRate);
    const ch = buf.getChannelData(0);
    for (let i = 0; i < ch.length; i++) {
      const env = Math.sin((i / ch.length) * Math.PI);
      ch[i] = (Math.random() * 2 - 1) * env;
    }

    const src = ctx.createBufferSource();
    src.buffer = buf;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = isSprinting ? 950 + Math.random() * 250 : 720 + Math.random() * 180;
    filter.Q.value = 1.4;

    const gain = ctx.createGain();
    const vol = isCrouching ? 0.025 : isSprinting ? 0.095 : 0.055;
    gain.gain.setValueAtTime(vol, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + dur);

    src.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    src.start(t);
  }

  public updateHeartbeat(bpm: number, dangerLevel: number) {
    if (dangerLevel < 0.18 && bpm < 95) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = performance.now();
    const beatInterval = (60 / Math.max(60, bpm)) * 1000;
    if (now - this.lastHeartbeatTime < beatInterval) return;
    this.lastHeartbeatTime = now;

    const t = ctx.currentTime;
    const playThump = (offset: number, freq: number, amp: number) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t + offset);
      osc.frequency.exponentialRampToValueAtTime(28, t + offset + 0.13);

      gain.gain.setValueAtTime(amp, t + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.14);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t + offset);
      osc.stop(t + offset + 0.15);
    };

    const intensity = Math.min(0.26, 0.05 + dangerLevel * 0.2);
    playThump(0, 62, intensity);
    playThump(0.16, 52, intensity * 0.72);
  }

  public playFlashlightClick() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const t = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(1900, t);
    osc.frequency.exponentialRampToValueAtTime(420, t + 0.03);

    gain.gain.setValueAtTime(0.11, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.035);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(t);
    osc.stop(t + 0.04);
  }

  public playMonsterGrowl(archetype: 'stalker' | 'wendigo' | 'creeper', distance: number, isStunned = false) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const attenuation = Math.max(0.02, Math.min(1, 1 - distance / 55));
    if (attenuation <= 0.03) return;

    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const mod = ctx.createOscillator();
    const modGain = ctx.createGain();
    const gain = ctx.createGain();

    const baseFreq =
      isStunned
        ? 310
        : archetype === 'wendigo'
          ? 68
          : archetype === 'stalker'
            ? 105
            : 155;

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(baseFreq, t);
    osc.frequency.linearRampToValueAtTime(isStunned ? baseFreq * 1.45 : baseFreq * 0.72, t + 0.65);

    mod.type = 'sine';
    mod.frequency.value = 26;
    modGain.gain.value = 32;
    mod.connect(modGain);
    modGain.connect(osc.frequency);

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = isStunned ? 1200 : 520;

    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(0.18 * attenuation, t + 0.09);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.75);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    osc.start(t);
    mod.start(t);
    osc.stop(t + 0.78);
    mod.stop(t + 0.78);
  }

  public playFlareIgnite() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const t = ctx.currentTime;

    const dur = 0.65;
    const buf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * dur), ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.35));
    }

    const src = ctx.createBufferSource();
    src.buffer = buf;

    const filter = ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.value = 1400;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + dur);

    src.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    src.start(t);
  }

  public playPickupChime() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(520, t);
    osc.frequency.setValueAtTime(760, t + 0.07);

    gain.gain.setValueAtTime(0.09, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.22);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(t);
    osc.stop(t + 0.24);
  }

  public playBeaconActivated() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const t = ctx.currentTime;
    const freqs = [440, 554.37, 659.25, 880];
    freqs.forEach((f, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.value = f;
      gain.gain.setValueAtTime(0.1, t + idx * 0.09);
      gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.09 + 0.32);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t + idx * 0.09);
      osc.stop(t + idx * 0.09 + 0.35);
    });
  }

  public playPlayerHit() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(140, t);
    osc.frequency.exponentialRampToValueAtTime(38, t + 0.28);

    gain.gain.setValueAtTime(0.28, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(t);
    osc.stop(t + 0.32);
  }
}

export const soundEngine = new HorrorSoundEngine();
