import * as THREE from 'three';
import { createBarkTextures, createForestGroundTextures } from './proceduralTextures';
import { CollectibleItem, RadioBeacon } from './types';

export interface TreeObstacle {
  x: number;
  z: number;
  radius: number;
}

export interface ForestWorldBuildResult {
  obstacles: TreeObstacle[];
  beacons: RadioBeacon[];
  collectibles: CollectibleItem[];
  extractionZone: {
    position: THREE.Vector3;
    radius: number;
    floodLight: THREE.PointLight;
    beaconColumn: THREE.Mesh;
  };
  particles: THREE.Points;
}

export function buildForestWorld(scene: THREE.Scene): ForestWorldBuildResult {
  const obstacles: TreeObstacle[] = [];
  const beacons: RadioBeacon[] = [];
  const collectibles: CollectibleItem[] = [];

  // 1. Forest Floor with realistic procedural soil/moss/pine-needle PBR texture
  const { map: groundMap, bumpMap: groundBump } = createForestGroundTextures();
  const groundGeo = new THREE.PlaneGeometry(280, 280, 64, 64);
  groundGeo.rotateX(-Math.PI / 2);

  const groundMat = new THREE.MeshStandardMaterial({
    map: groundMap,
    bumpMap: groundBump,
    bumpScale: 0.08,
    roughness: 0.92,
    metalness: 0.03,
  });
  const groundMesh = new THREE.Mesh(groundGeo, groundMat);
  groundMesh.receiveShadow = true;
  scene.add(groundMesh);

  // 2. Tree Materials
  const { map: barkMap, bumpMap: barkBump } = createBarkTextures();
  const barkMat = new THREE.MeshStandardMaterial({
    map: barkMap,
    bumpMap: barkBump,
    bumpScale: 0.06,
    roughness: 0.9,
  });

  const foliageDarkMat = new THREE.MeshStandardMaterial({
    color: 0x0d1b13,
    roughness: 0.88,
  });

  const foliageMidMat = new THREE.MeshStandardMaterial({
    color: 0x13261b,
    roughness: 0.85,
  });

  const rockMat = new THREE.MeshStandardMaterial({
    color: 0x262c29,
    bumpMap: groundBump,
    bumpScale: 0.05,
    roughness: 0.86,
  });

  // Protected clearings (Spawn + 4 Beacons + Extraction)
  const clearings = [
    { x: 0, z: 0, r: 9 },       // Player Start
    { x: -46, z: 32, r: 10 },   // Beacon 1: Crashed SUV
    { x: 48, z: 28, r: 10 },    // Beacon 2: Ranger Watchtower
    { x: -44, z: -46, r: 10 },  // Beacon 3: Abandoned Camp
    { x: 46, z: -48, r: 10 },   // Beacon 4: Stone Altar
    { x: 0, z: -88, r: 13 },    // Northern Extraction Zone
  ];

  const isInsideClearing = (x: number, z: number) => {
    return clearings.some((c) => Math.hypot(x - c.x, z - c.z) < c.r);
  };

  // 3. Populate Dense Realistic Pine & Gnarled Trees
  for (let i = 0; i < 290; i++) {
    const angle = Math.random() * Math.PI * 2;
    const dist = 10 + Math.random() * 112;
    const x = Math.cos(angle) * dist;
    const z = Math.sin(angle) * dist;

    if (isInsideClearing(x, z)) continue;

    const treeGroup = new THREE.Group();
    treeGroup.position.set(x, 0, z);

    const scale = 0.85 + Math.random() * 0.75;
    const trunkRadius = 0.34 * scale;
    const trunkHeight = (6.5 + Math.random() * 4.5) * scale;

    // Trunk + Flared Roots
    const trunk = new THREE.Mesh(
      new THREE.CylinderGeometry(trunkRadius * 0.55, trunkRadius * 1.25, trunkHeight, 9),
      barkMat
    );
    trunk.position.y = trunkHeight * 0.5;
    trunk.castShadow = true;
    trunk.receiveShadow = true;
    treeGroup.add(trunk);

    // 4 Tiered Conifer Needles or Gnarled Dead Branches
    if (Math.random() > 0.14) {
      const tiers = 4;
      for (let t = 0; t < tiers; t++) {
        const coneR = (2.6 - t * 0.45) * scale;
        const coneH = (3.4 - t * 0.35) * scale;
        const tierMesh = new THREE.Mesh(
          new THREE.ConeGeometry(coneR, coneH, 9),
          t % 2 === 0 ? foliageDarkMat : foliageMidMat
        );
        tierMesh.position.y = trunkHeight * 0.48 + t * (1.55 * scale);
        tierMesh.rotation.y = Math.random() * Math.PI;
        tierMesh.castShadow = true;
        treeGroup.add(tierMesh);
      }
    } else {
      // Dead Gnarled Horror Tree
      for (let b = 0; b < 4; b++) {
        const branch = new THREE.Mesh(
          new THREE.CylinderGeometry(0.04 * scale, 0.12 * scale, 2.6 * scale, 6),
          barkMat
        );
        branch.position.y = trunkHeight * (0.55 + b * 0.1);
        branch.rotation.z = (b % 2 === 0 ? 1 : -1) * (0.6 + Math.random() * 0.4);
        branch.rotation.y = b * 1.5;
        treeGroup.add(branch);
      }
    }

    scene.add(treeGroup);
    obstacles.push({ x, z, radius: trunkRadius * 1.15 });
  }

  // 4. Add Mossy Boulders & Fallen Logs
  for (let i = 0; i < 75; i++) {
    const x = (Math.random() - 0.5) * 210;
    const z = (Math.random() - 0.5) * 210;
    if (isInsideClearing(x, z)) continue;

    const r = 0.6 + Math.random() * 1.2;
    const boulder = new THREE.Mesh(new THREE.DodecahedronGeometry(r, 1), rockMat);
    boulder.scale.set(1.2, 0.72, 1.0);
    boulder.position.set(x, r * 0.4, z);
    boulder.rotation.set(Math.random(), Math.random(), Math.random());
    boulder.castShadow = true;
    boulder.receiveShadow = true;
    scene.add(boulder);

    if (r > 1.0) {
      obstacles.push({ x, z, radius: r * 0.9 });
    }
  }

  // 5. Helper to build an Emergency Radio Beacon Tower at a Landmark
  const createBeaconTower = (
    id: string,
    nameAr: string,
    locationNameAr: string,
    pos: THREE.Vector3
  ): RadioBeacon => {
    const group = new THREE.Group();
    group.position.copy(pos);

    const metalMat = new THREE.MeshStandardMaterial({
      color: 0x3b4440,
      metalness: 0.75,
      roughness: 0.35,
    });
    const hazardMat = new THREE.MeshStandardMaterial({
      color: 0xd9822b,
      roughness: 0.45,
    });

    // Concrete base & generator box
    const base = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.4, 1.3), rockMat);
    base.position.y = 0.2;
    base.castShadow = true;
    group.add(base);

    const consoleBox = new THREE.Mesh(new THREE.BoxGeometry(0.85, 1.25, 0.65), metalMat);
    consoleBox.position.y = 1.0;
    consoleBox.castShadow = true;
    group.add(consoleBox);

    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.88, 0.18, 0.68), hazardMat);
    stripe.position.y = 1.35;
    group.add(stripe);

    // Tall lattice radio mast
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.11, 5.2, 8), metalMat);
    mast.position.y = 3.8;
    mast.castShadow = true;
    group.add(mast);

    // Dish receiver
    const dish = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.1, 0.2, 14), metalMat);
    dish.rotation.x = Math.PI / 2;
    dish.position.set(0, 5.4, 0.18);
    group.add(dish);

    // Status Lamp (Red when offline, Bright Emerald Green when activated)
    const statusLampMat = new THREE.MeshStandardMaterial({
      color: 0xff3b30,
      emissive: 0xd92b2b,
      emissiveIntensity: 3.2,
    });
    const lampBulb = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 12), statusLampMat);
    lampBulb.position.y = 6.45;
    group.add(lampBulb);

    const beaconLight = new THREE.PointLight(0xff3b30, 2.8, 18, 1.5);
    beaconLight.position.set(0, 6.5, 0);
    group.add(beaconLight);

    scene.add(group);
    obstacles.push({ x: pos.x, z: pos.z, radius: 0.85 });

    return {
      id,
      nameAr,
      locationNameAr,
      position: pos.clone(),
      activated: false,
      activationProgress: 0,
      meshGroup: group,
      beaconLight,
      statusLampMat,
    };
  };

  // Build Landmark Props + 4 Beacons
  // Landmark 1: Crashed Expedition SUV (-46, 32)
  const suvGroup = new THREE.Group();
  suvGroup.position.set(-49.5, 0, 34);
  suvGroup.rotation.y = 0.65;
  suvGroup.rotation.z = 0.12;
  const carBodyMat = new THREE.MeshStandardMaterial({ color: 0x324238, metalness: 0.5, roughness: 0.5 });
  const suvChassis = new THREE.Mesh(new THREE.BoxGeometry(2.1, 1.1, 4.3), carBodyMat);
  suvChassis.position.y = 0.75;
  suvChassis.castShadow = true;
  suvGroup.add(suvChassis);
  const suvCabin = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.85, 2.4), carBodyMat);
  suvCabin.position.set(0, 1.65, -0.3);
  suvGroup.add(suvCabin);
  scene.add(suvGroup);
  obstacles.push({ x: -49.5, z: 34, radius: 2.3 });

  beacons.push(
    createBeaconTower('beacon-1', 'برج الإشارة الأول', 'حطام مركبة الاستطلاع', new THREE.Vector3(-46, 0, 32))
  );

  // Landmark 2: Old Ranger Watchtower (48, 28)
  const towerFrame = new THREE.Group();
  towerFrame.position.set(52, 0, 29);
  for (const [lx, lz] of [[-1.5, -1.5], [1.5, -1.5], [-1.5, 1.5], [1.5, 1.5]]) {
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.18, 7.5, 8), barkMat);
    post.position.set(lx, 3.75, lz);
    post.castShadow = true;
    towerFrame.add(post);
  }
  const platform = new THREE.Mesh(new THREE.BoxGeometry(3.8, 0.3, 3.8), barkMat);
  platform.position.y = 7.2;
  towerFrame.add(platform);
  scene.add(towerFrame);

  beacons.push(
    createBeaconTower('beacon-2', 'برج الإشارة الثاني', 'مرصد الحراس المهجور', new THREE.Vector3(48, 0, 28))
  );

  // Landmark 3: Abandoned Campfire & Tent (-44, -46)
  const tentMat = new THREE.MeshStandardMaterial({ color: 0x4a3d2c, roughness: 0.9, side: THREE.DoubleSide });
  const tent = new THREE.Mesh(new THREE.ConeGeometry(2.2, 2.1, 4), tentMat);
  tent.position.set(-48, 1.05, -45);
  tent.rotation.y = 0.4;
  tent.castShadow = true;
  scene.add(tent);
  const emberLight = new THREE.PointLight(0xff6a1a, 1.8, 11);
  emberLight.position.set(-45, 0.4, -49);
  scene.add(emberLight);

  beacons.push(
    createBeaconTower('beacon-3', 'برج الإشارة الثالث', 'مخيم البعثة المفقودة', new THREE.Vector3(-44, -46, 0).setY(0).setZ(-46))
  );

  // Landmark 4: Ancient Stone Monoliths (46, -48)
  for (let m = 0; m < 5; m++) {
    const ang = (m / 5) * Math.PI * 2;
    const monolith = new THREE.Mesh(new THREE.BoxGeometry(0.9, 3.8, 0.55), rockMat);
    monolith.position.set(46 + Math.cos(ang) * 4.5, 1.9, -48 + Math.sin(ang) * 4.5);
    monolith.rotation.y = -ang;
    monolith.castShadow = true;
    scene.add(monolith);
  }

  beacons.push(
    createBeaconTower('beacon-4', 'برج الإشارة الرابع', 'الأطلال الحجرية القديمة', new THREE.Vector3(46, 0, -48))
  );

  // 6. Northern Extraction Zone / Rescue Helipad (0, 0, -88)
  const extractionPos = new THREE.Vector3(0, 0, -88);
  const helipadGroup = new THREE.Group();
  helipadGroup.position.copy(extractionPos);

  const padCircle = new THREE.Mesh(
    new THREE.CylinderGeometry(5.5, 5.8, 0.25, 28),
    new THREE.MeshStandardMaterial({ color: 0x252c29, roughness: 0.8 })
  );
  padCircle.position.y = 0.12;
  padCircle.receiveShadow = true;
  helipadGroup.add(padCircle);

  const padRing = new THREE.Mesh(
    new THREE.RingGeometry(4.2, 4.6, 28),
    new THREE.MeshBasicMaterial({ color: 0xd9822b, side: THREE.DoubleSide })
  );
  padRing.rotation.x = -Math.PI / 2;
  padRing.position.y = 0.26;
  helipadGroup.add(padRing);

  // Vertical Light Column (becomes intense green when all 4 beacons are active)
  const beaconColumn = new THREE.Mesh(
    new THREE.CylinderGeometry(0.8, 0.8, 36, 16, 1, true),
    new THREE.MeshBasicMaterial({
      color: 0x38b566,
      transparent: true,
      opacity: 0.0,
      side: THREE.DoubleSide,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    })
  );
  beaconColumn.position.y = 18;
  helipadGroup.add(beaconColumn);

  const extractionFloodLight = new THREE.PointLight(0x38b566, 0, 32, 1.2);
  extractionFloodLight.position.set(0, 4.5, 0);
  helipadGroup.add(extractionFloodLight);

  scene.add(helipadGroup);

  // 7. Create Collectible Survival Supplies & Lore Notes
  const addCollectible = (
    id: string,
    type: CollectibleItem['type'],
    labelAr: string,
    x: number,
    z: number,
    noteTextAr?: string
  ) => {
    const group = new THREE.Group();
    group.position.set(x, 0.35, z);

    const glowColor =
      type === 'battery'
        ? 0x3898ff
        : type === 'flare'
          ? 0xff4538
          : type === 'medkit'
            ? 0x38b566
            : 0xf5b841;

    if (type === 'battery') {
      const bat = new THREE.Mesh(
        new THREE.CylinderGeometry(0.14, 0.14, 0.36, 12),
        new THREE.MeshStandardMaterial({ color: 0x2563eb, emissive: 0x1d4ed8, emissiveIntensity: 0.8, metalness: 0.6 })
      );
      group.add(bat);
    } else if (type === 'flare') {
      const flr = new THREE.Mesh(
        new THREE.CylinderGeometry(0.08, 0.08, 0.42, 10),
        new THREE.MeshStandardMaterial({ color: 0xdc2626, emissive: 0x991b1b, emissiveIntensity: 0.9 })
      );
      flr.rotation.z = 0.4;
      group.add(flr);
    } else if (type === 'medkit') {
      const box = new THREE.Mesh(
        new THREE.BoxGeometry(0.38, 0.26, 0.28),
        new THREE.MeshStandardMaterial({ color: 0x16a34a, emissive: 0x14532d, emissiveIntensity: 0.7 })
      );
      group.add(box);
    } else {
      const journal = new THREE.Mesh(
        new THREE.BoxGeometry(0.32, 0.06, 0.42),
        new THREE.MeshStandardMaterial({ color: 0xd9822b, emissive: 0x92400e, emissiveIntensity: 0.8 })
      );
      group.add(journal);
    }

    // Subtle floating indicator ring
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(0.32, 0.38, 16),
      new THREE.MeshBasicMaterial({ color: glowColor, side: THREE.DoubleSide, transparent: true, opacity: 0.65 })
    );
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = -0.3;
    group.add(ring);

    scene.add(group);
    collectibles.push({
      id,
      type,
      labelAr,
      position: new THREE.Vector3(x, 0.35, z),
      mesh: group,
      collected: false,
      noteTextAr,
    });
  };

  // Scatter helpful supplies near paths and landmarks
  addCollectible(
    'note-start',
    'note',
    'مذكرة قائد الدورية (١)',
    3.5,
    -4.5,
    '«تحطمت مركبتنا عند أطراف وادي الظلام... الكائنات هنا ليست حيوانات عادية؛ إنها تفرّ من الضوء المركز والنار. فعّل أبراج الإشارة الأربعة لطلب مروحية الإخلاء شمالاً!»'
  );
  addCollectible('bat-1', 'battery', 'بطارية ليثيوم للكشاف', -14, 12);
  addCollectible('flare-1', 'flare', 'حزمة مشاعل حرارية', 12, 10);
  addCollectible('med-1', 'medkit', 'حقيبة إسعافات ميدانية', -28, 22);
  addCollectible('bat-2', 'battery', 'بطارية ليثيوم للكشاف', -43, 35);
  addCollectible(
    'note-2',
    'note',
    'تقرير الباحث البيولوجي (٢)',
    44,
    25,
    '«حارس القرون (الوينديغو) يسمع وقع الأقدام عند الركض. انحنِ بالضغط على [C] وأطفئ الكشاف إذا أردت التسلل دون أن يراك، أو استخدم الشعاع العالي لحرق عينيه!»'
  );
  addCollectible('flare-2', 'flare', 'حزمة مشاعل حرارية', 50, 31);
  addCollectible('med-2', 'medkit', 'حقيبة إسعافات ميدانية', -41, -43);
  addCollectible('bat-3', 'battery', 'بطارية ليثيوم للكشاف', -47, -48);
  addCollectible('flare-3', 'flare', 'حزمة مشاعل حرارية', 43, -45);
  addCollectible('med-3', 'medkit', 'حقيبة إسعافات ميدانية', 18, -36);
  addCollectible('bat-4', 'battery', 'بطارية ليثيوم للكشاف', -15, -62);
  addCollectible('flare-4', 'flare', 'حزمة مشاعل حرارية', 4, -72);

  // 8. Atmospheric Floating Nocturnal Spores / Mist Particles
  const particleCount = 700;
  const positions = new Float32Array(particleCount * 3);
  for (let i = 0; i < particleCount; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 180;
    positions[i * 3 + 1] = 0.3 + Math.random() * 6.5;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 180;
  }
  const partGeo = new THREE.BufferGeometry();
  partGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const partMat = new THREE.PointsMaterial({
    color: 0x9bb5a6,
    size: 0.14,
    transparent: true,
    opacity: 0.38,
    depthWrite: false,
  });
  const particles = new THREE.Points(partGeo, partMat);
  scene.add(particles);

  return {
    obstacles,
    beacons,
    collectibles,
    extractionZone: {
      position: extractionPos,
      radius: 5.5,
      floodLight: extractionFloodLight,
      beaconColumn,
    },
    particles,
  };
}
