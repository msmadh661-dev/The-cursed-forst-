import * as THREE from 'three';

class TextureCache {
  private static cache: Map<string, THREE.CanvasTexture> = new Map();

  static getOrCreate(
    key: string,
    width: number,
    height: number,
    drawFn: (ctx: CanvasRenderingContext2D, w: number, h: number) => void,
    repeatX = 1,
    repeatY = 1
  ): THREE.CanvasTexture {
    const existing = this.cache.get(key);
    if (existing) return existing;

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d')!;
    drawFn(ctx, width, height);

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(repeatX, repeatY);
    texture.needsUpdate = true;
    this.cache.set(key, texture);
    return texture;
  }
}

export function createForestGroundTextures() {
  const map = TextureCache.getOrCreate('forest_ground_albedo', 512, 512, (ctx, w, h) => {
    ctx.fillStyle = '#0e1713';
    ctx.fillRect(0, 0, w, h);

    // Organic soil, moss patches, fallen pine needles
    for (let i = 0; i < 6500; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      const r = 1 + Math.random() * 5;
      const palette = ['#0b120e', '#14221a', '#1b261c', '#181410', '#211c15'];
      ctx.fillStyle = palette[Math.floor(Math.random() * palette.length)];
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }

    // Small twigs / pine needles
    ctx.strokeStyle = 'rgba(42, 34, 24, 0.55)';
    ctx.lineWidth = 1.2;
    for (let i = 0; i < 900; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      const angle = Math.random() * Math.PI * 2;
      const len = 3 + Math.random() * 7;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + Math.cos(angle) * len, y + Math.sin(angle) * len);
      ctx.stroke();
    }
  }, 45, 45);

  const bumpMap = TextureCache.getOrCreate('forest_ground_bump', 512, 512, (ctx, w, h) => {
    ctx.fillStyle = '#808080';
    ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 8000; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      const v = Math.floor(70 + Math.random() * 120);
      ctx.fillStyle = `rgb(${v},${v},${v})`;
      ctx.fillRect(x, y, 2 + Math.random() * 3, 2 + Math.random() * 3);
    }
  }, 45, 45);

  return { map, bumpMap };
}

export function createBarkTextures() {
  const map = TextureCache.getOrCreate('bark_albedo', 256, 256, (ctx, w, h) => {
    ctx.fillStyle = '#221a14';
    ctx.fillRect(0, 0, w, h);

    for (let i = 0; i < 900; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      const bw = 2 + Math.random() * 5;
      const bh = 16 + Math.random() * 42;
      const shade = ['#17110d', '#2b2119', '#33281f', '#1c241b'][Math.floor(Math.random() * 4)];
      ctx.fillStyle = shade;
      ctx.fillRect(x, y, bw, bh);
    }
  }, 2, 6);

  const bumpMap = TextureCache.getOrCreate('bark_bump', 256, 256, (ctx, w, h) => {
    ctx.fillStyle = '#707070';
    ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 1100; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      const v = Math.floor(40 + Math.random() * 170);
      ctx.fillStyle = `rgb(${v},${v},${v})`;
      ctx.fillRect(x, y, 2 + Math.random() * 3, 18 + Math.random() * 35);
    }
  }, 2, 6);

  return { map, bumpMap };
}

export function createFabricTexture(baseHex: string, mudStains = true) {
  const key = `fabric_${baseHex}_${mudStains}`;
  const map = TextureCache.getOrCreate(key, 256, 256, (ctx, w, h) => {
    ctx.fillStyle = baseHex;
    ctx.fillRect(0, 0, w, h);

    // Fine woven canvas pattern
    ctx.fillStyle = 'rgba(0,0,0,0.12)';
    for (let y = 0; y < h; y += 3) {
      ctx.fillRect(0, y, w, 1);
    }
    ctx.fillStyle = 'rgba(255,255,255,0.04)';
    for (let x = 0; x < w; x += 3) {
      ctx.fillRect(x, 0, 1, h);
    }

    if (mudStains) {
      for (let i = 0; i < 85; i++) {
        const x = Math.random() * w;
        const y = Math.random() * h;
        const r = 4 + Math.random() * 18;
        ctx.fillStyle = 'rgba(22, 18, 14, 0.16)';
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }, 2, 2);

  return map;
}

export function createHumanSkinTexture() {
  return TextureCache.getOrCreate('human_skin_real', 256, 256, (ctx, w, h) => {
    // Warm realistic Mediterranean / Middle-Eastern weathered skin tone
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, '#c69477');
    grad.addColorStop(0.5, '#b88568');
    grad.addColorStop(1, '#a37257');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, w, h);

    // Subtle pores, dirt smudges from surviving in the forest
    for (let i = 0; i < 1200; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      ctx.fillStyle = Math.random() > 0.5 ? 'rgba(90, 55, 40, 0.08)' : 'rgba(235, 195, 170, 0.06)';
      ctx.fillRect(x, y, 2, 2);
    }
    // Forest soot / smudges
    for (let i = 0; i < 25; i++) {
      ctx.fillStyle = 'rgba(35, 28, 22, 0.11)';
      ctx.beginPath();
      ctx.arc(Math.random() * w, Math.random() * h, 6 + Math.random() * 14, 0, Math.PI * 2);
      ctx.fill();
    }
  });
}

export function createMonsterHideTextures(variant: 'stalker' | 'wendigo' | 'creeper') {
  const baseColor =
    variant === 'stalker' ? '#2c2f2d' : variant === 'wendigo' ? '#231d19' : '#262b30';
  const veinColor =
    variant === 'stalker' ? 'rgba(18, 12, 14, 0.45)' : variant === 'wendigo' ? 'rgba(48, 20, 16, 0.4)' : 'rgba(15, 24, 30, 0.45)';

  const map = TextureCache.getOrCreate(`monster_hide_${variant}`, 256, 256, (ctx, w, h) => {
    ctx.fillStyle = baseColor;
    ctx.fillRect(0, 0, w, h);

    // Sinew & muscle striations
    for (let i = 0; i < 650; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      ctx.fillStyle = Math.random() > 0.4 ? 'rgba(12, 14, 13, 0.3)' : 'rgba(95, 100, 92, 0.14)';
      ctx.fillRect(x, y, 2 + Math.random() * 4, 12 + Math.random() * 28);
    }

    // Dark corrupted veins & scars
    ctx.strokeStyle = veinColor;
    ctx.lineWidth = 1.6;
    for (let i = 0; i < 95; i++) {
      let cx = Math.random() * w;
      let cy = Math.random() * h;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      for (let s = 0; s < 5; s++) {
        cx += (Math.random() - 0.5) * 22;
        cy += (Math.random() - 0.5) * 22;
        ctx.lineTo(cx, cy);
      }
      ctx.stroke();
    }
  });

  const bumpMap = TextureCache.getOrCreate(`monster_bump_${variant}`, 256, 256, (ctx, w, h) => {
    ctx.fillStyle = '#808080';
    ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 1400; i++) {
      const v = Math.floor(45 + Math.random() * 165);
      ctx.fillStyle = `rgb(${v},${v},${v})`;
      ctx.fillRect(Math.random() * w, Math.random() * h, 3, 14);
    }
  });

  return { map, bumpMap };
}

export function createBoneSkullTexture() {
  return TextureCache.getOrCreate('bone_skull_tex', 256, 256, (ctx, w, h) => {
    ctx.fillStyle = '#b9b19f';
    ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 800; i++) {
      ctx.fillStyle = Math.random() > 0.5 ? 'rgba(65, 52, 38, 0.16)' : 'rgba(225, 218, 200, 0.14)';
      ctx.fillRect(Math.random() * w, Math.random() * h, 3 + Math.random() * 6, 3 + Math.random() * 6);
    }
    // Cracks and dried blood/moss stains
    ctx.strokeStyle = 'rgba(40, 30, 22, 0.45)';
    ctx.lineWidth = 1.2;
    for (let i = 0; i < 35; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + (Math.random() - 0.5) * 30, y + (Math.random() - 0.5) * 30);
      ctx.stroke();
    }
  });
}
