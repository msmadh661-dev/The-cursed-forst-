import * as THREE from 'three';

export type GamePhase = 'title' | 'playing' | 'paused' | 'victory' | 'gameover';
export type CameraPerspective = 'third-person' | 'first-person';
export type DifficultyLevel = 'normal' | 'hardcore';

export type MonsterArchetype = 'stalker' | 'wendigo' | 'creeper';

export interface MonsterEntity {
  id: string;
  nameAr: string;
  archetype: MonsterArchetype;
  meshGroup: THREE.Group;
  joints: {
    pelvis: THREE.Group;
    torso: THREE.Group;
    neck: THREE.Group;
    head: THREE.Group;
    jaw?: THREE.Group;
    leftShoulder: THREE.Group;
    leftForearm: THREE.Group;
    rightShoulder: THREE.Group;
    rightForearm: THREE.Group;
    leftHip: THREE.Group;
    leftCalf: THREE.Group;
    rightHip: THREE.Group;
    rightCalf: THREE.Group;
    eyesMaterial: THREE.MeshStandardMaterial;
  };
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  rotationY: number;
  state: 'patrol' | 'investigate' | 'chase' | 'stunned' | 'retreat';
  health: number;
  maxHealth: number;
  speedPatrol: number;
  speedChase: number;
  detectionRadius: number;
  attackDamage: number;
  attackCooldown: number;
  stunTimer: number;
  burnExposure: number; // accumulates when hit by focused flashlight beam
  patrolTarget: THREE.Vector3;
  animPhase: number;
  lastGrowlTime: number;
}

export type CollectibleType = 'battery' | 'flare' | 'medkit' | 'note';

export interface CollectibleItem {
  id: string;
  type: CollectibleType;
  labelAr: string;
  position: THREE.Vector3;
  mesh: THREE.Group;
  collected: boolean;
  noteTextAr?: string;
}

export interface RadioBeacon {
  id: string;
  nameAr: string;
  locationNameAr: string;
  position: THREE.Vector3;
  activated: boolean;
  activationProgress: number; // 0 to 100
  meshGroup: THREE.Group;
  beaconLight: THREE.PointLight;
  statusLampMat: THREE.MeshStandardMaterial;
}

export interface ActiveFlare {
  id: string;
  position: THREE.Vector3;
  mesh: THREE.Group;
  light: THREE.PointLight;
  remainingTime: number;
}

export interface PlayerStats {
  health: number;
  maxHealth: number;
  stamina: number;
  maxStamina: number;
  battery: number;
  maxBattery: number;
  flashlightOn: boolean;
  highBeamActive: boolean;
  isCrouching: boolean;
  isSprinting: boolean;
  flaresCount: number;
  medkitsCount: number;
  beaconsActivated: number;
  totalBeacons: number;
  extractionReady: boolean;
  extractionProgress: number;
  heartbeatBpm: number;
  nearestMonsterDist: number;
  dangerLevel: number; // 0 to 1
  noiseLevel: number; // 0 to 1
  headingDeg: number;
  cameraMode: CameraPerspective;
  activePromptAr: string | null;
  statusMessageAr: string;
  survivedSeconds: number;
  monstersRepelled: number;
  collectedNotes: string[];
}

export interface CompassMarker {
  id: string;
  labelAr: string;
  type: 'beacon' | 'extraction' | 'monster' | 'item';
  angleDeg: number;
  distance: number;
  activated?: boolean;
}
